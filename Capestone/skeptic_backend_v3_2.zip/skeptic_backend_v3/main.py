"""main.py — Skeptic Engine: corrected 3-path audit pipeline.

Observability stack:
  - LangSmith: traces every LLM/RAG call (challenger, defender, adjudicator,
    rag_retrieve, rag_answer_policy_question, run_pipeline_for_case). Enable
    via LANGSMITH_TRACING=true + LANGSMITH_API_KEY in .env.
  - Prometheus: GET /metrics exposes request metrics (via
    prometheus-fastapi-instrumentator) plus custom counters/histograms for
    token usage, LLM latency, RAG relevance/groundedness, and case routing —
    defined in app/core/telemetry.py.
"""
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from prometheus_fastapi_instrumentator import Instrumentator

from app.core.config import get_settings
from app.core.telemetry import init_langsmith
from app.db.database import init_db
from app.api.v1.router import api_router


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    init_langsmith()
    yield


def create_app() -> FastAPI:
    settings = get_settings()
    app = FastAPI(
        title="Skeptic Engine API",
        description=(
            "Phase 0 intake -> Phase 1 evidence (RAG) -> Phase 2 debate (with re-run loop) -> "
            "Phase 3 confidence gate with THREE INDEPENDENT routes: "
            "auto_clear and review go straight to report (no human); "
            "manual (forced escalation only) requires human review. "
            "Instrumented with LangSmith tracing and Prometheus metrics; "
            "token usage and RAG retrieval quality are independently queryable."
        ),
        version="3.1.0",
        lifespan=lifespan,
    )
    app.add_middleware(
        CORSMiddleware, allow_origins=settings.cors_origins_list,
        allow_credentials=True, allow_methods=["*"], allow_headers=["*"],
    )
    app.include_router(api_router)

    if settings.prometheus_enabled:
        Instrumentator().instrument(app).expose(app, endpoint="/metrics", tags=["Observability"])

    @app.get("/health", tags=["health"])
    async def health():
        return {"status": "ok", "version": "3.1.0"}

    return app


app = create_app()

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
