"""app/agents/pipeline.py
Phase 1a — transaction classification + 3rd-party validation (PNR/GSTIN/benchmark)
Phase 2 — adversarial debate (Challenger + Defender + Adjudicator), each rerun
          must argue something NEW — prior arguments are shown to the agent
          and it is explicitly told not to repeat them.
Phase 3 — confidence gate with a HARD 3-attempt cap and 3 INDEPENDENT exit paths:

  auto_clear  -> report directly, no human            (score >= 0.90, risk low/cleared)
  review      -> report directly, no human            (score 0.70-0.89, risk not high/critical)
  manual      -> human review REQUIRED before report  (risk high/critical, OR confidence < 0.70,
                                                          OR the debate used all 3 allowed
                                                          attempts without an early confident exit
                                                          — this last case is forced manual
                                                          REGARDLESS of the final confidence/risk)

Review queue and manual queue NEVER merge into the same human-review step.
"""
from __future__ import annotations
import json
import random
from datetime import datetime, timezone

from groq import Groq
from langsmith import traceable

from app.core.config import get_settings
from app.core.telemetry import DEBATE_ROUNDS_TOTAL, CASE_ROUTING_TOTAL, time_llm_call
from app.db.database import get_db
from app.services.audit_log_service import append_event
from app.services.evidence_service import collect_evidence
from app.services.token_usage_service import log_token_usage

GROQ_MODEL = "llama-3.1-8b-instant"


@traceable(name="llm_call", run_type="llm")
def _llm(system: str, user: str, temperature: float = 0.2, max_tokens: int = 500,
         agent: str = "unknown", case_id: str | None = None) -> str:
    settings = get_settings()
    client = Groq(api_key=settings.groq_api_key)
    with time_llm_call(agent=agent, model=GROQ_MODEL):
        import time
        start = time.perf_counter()
        resp = client.chat.completions.create(
            model=GROQ_MODEL, max_tokens=max_tokens, temperature=temperature,
            messages=[{"role": "system", "content": system}, {"role": "user", "content": user}],
        )
        latency_ms = (time.perf_counter() - start) * 1000

    usage = getattr(resp, "usage", None)
    prompt_tokens = getattr(usage, "prompt_tokens", 0) or 0
    completion_tokens = getattr(usage, "completion_tokens", 0) or 0
    log_token_usage(agent, GROQ_MODEL, prompt_tokens, completion_tokens, latency_ms, case_id=case_id)

    return resp.choices[0].message.content.strip()


_CHALLENGER_ANGLES = [
    "the transaction's documentary evidence and paper trail",
    "the behavioral pattern of the person who posted it (timing, frequency, authority)",
    "the financial materiality and downstream accounting impact",
    "comparison against company policy and what a compliant transaction would look like instead",
]
_DEFENDER_ANGLES = [
    "the transaction's legitimate documentary support",
    "the business context and operational necessity",
    "the posting employee's normal role, authority, and history",
    "industry/market norms that make this look ordinary rather than suspicious",
]


def _run_challenger(transaction: dict, evidence: dict, attempt: int,
                    case_id: str | None = None, prior_arguments: list[str] | None = None) -> dict:
    system = ("You are an adversarial audit examiner. Build the strongest possible risk argument "
              "from the evidence. Never concede a point. On every rerun you must produce a "
              "substantively different argument — reusing your own earlier wording is a failure.")
    rerun_note = ""
    if prior_arguments:
        joined = "\n".join(f"  Attempt {i+1}: {a}" for i, a in enumerate(prior_arguments))
        next_angle = _CHALLENGER_ANGLES[len(prior_arguments) % len(_CHALLENGER_ANGLES)]
        rerun_note = (
            f"\n\nYour own prior arguments in this same debate (DO NOT repeat or rephrase these):\n{joined}\n"
            f"For this attempt, build your argument specifically around: {next_angle}. "
            f"If that angle is not applicable to this transaction, pick whichever unused angle fits best, "
            f"but it must be clearly different from every attempt listed above."
        )
    user = f"""Transaction: {json.dumps(transaction)}
Evidence: {json.dumps(evidence)}
Attempt: {attempt}{rerun_note}

List the top risk factors and assign a risk confidence (0-1) for why this transaction should be flagged as suspicious. Respond in 3-4 sentences."""
    text = _llm(system, user, temperature=min(0.9, 0.3 + attempt * 0.2), agent="challenger", case_id=case_id)
    confidence = round(min(0.95, 0.55 + 0.1 * len(evidence.get("transaction_summary", {}).get("flags", []))), 2)
    return {"argument": text, "confidence": confidence, "side": "challenger"}


def _run_defender(transaction: dict, evidence: dict, attempt: int,
                  case_id: str | None = None, prior_arguments: list[str] | None = None) -> dict:
    system = ("You are defence counsel for this transaction. Build the strongest legitimate business "
              "rationale. Find every mitigating factor. On every rerun you must produce a substantively "
              "different argument — reusing your own earlier wording is a failure.")
    rerun_note = ""
    if prior_arguments:
        joined = "\n".join(f"  Attempt {i+1}: {a}" for i, a in enumerate(prior_arguments))
        next_angle = _DEFENDER_ANGLES[len(prior_arguments) % len(_DEFENDER_ANGLES)]
        rerun_note = (
            f"\n\nYour own prior arguments in this same debate (DO NOT repeat or rephrase these):\n{joined}\n"
            f"For this attempt, build your argument specifically around: {next_angle}. "
            f"If that angle is not applicable to this transaction, pick whichever unused angle fits best, "
            f"but it must be clearly different from every attempt listed above."
        )
    user = f"""Transaction: {json.dumps(transaction)}
Evidence: {json.dumps(evidence)}
Attempt: {attempt}{rerun_note}

Argue why this transaction is likely legitimate despite the flags. Respond in 3-4 sentences."""
    text = _llm(system, user, temperature=min(0.9, 0.3 + attempt * 0.2), agent="defender", case_id=case_id)
    confidence = round(max(0.2, 0.6 - 0.08 * len(evidence.get("transaction_summary", {}).get("flags", []))), 2)
    return {"argument": text, "confidence": confidence, "side": "defender"}


def _run_adjudicator(transaction: dict, evidence: dict, challenger: dict, defender: dict, attempt: int,
                     case_id: str | None = None) -> dict:
    system = "You are the lead audit partner. Weigh both arguments impartially against company policy and produce a final verdict."
    user = f"""Transaction: {json.dumps(transaction)}
Challenger argument (confidence {challenger['confidence']}): {challenger['argument']}
Defender argument (confidence {defender['confidence']}): {defender['argument']}
Attempt number: {attempt}

Respond with: RISK=<critical|high|medium|low|cleared> CONFIDENCE=<0.0-1.0> DISPOSITION=<escalate|review|clear> SUMMARY=<one sentence>"""
    text = _llm(system, user, temperature=0.15, max_tokens=300, agent="adjudicator", case_id=case_id)

    risk, confidence, disposition, summary = "medium", 0.5, "review", text[:200]
    for line in text.replace("\n", " ").split():
        pass
    import re
    rm = re.search(r"RISK=(\w+)", text, re.IGNORECASE)
    cm = re.search(r"CONFIDENCE=([\d.]+)", text)
    dm = re.search(r"DISPOSITION=(\w+)", text, re.IGNORECASE)
    sm = re.search(r"SUMMARY=(.+)", text, re.IGNORECASE | re.DOTALL)
    if rm: risk = rm.group(1).lower()
    if cm:
        try:
            confidence = max(0.0, min(1.0, float(cm.group(1))))
        except ValueError:
            pass
    if dm: disposition = dm.group(1).lower()
    if sm: summary = sm.group(1).strip()[:300]

    # Blend in challenger/defender confidence gap as a sanity signal
    gap = abs(challenger["confidence"] - defender["confidence"])
    if gap < 0.15:
        confidence = round(confidence * 0.85, 2)  # ambiguous debate -> lower confidence

    return {
        "risk": risk, "confidence": confidence, "disposition": disposition,
        "summary": summary, "raw": text,
    }


@traceable(name="debate_round", run_type="chain")
async def run_debate_round(case_id: str, transaction: dict, evidence: dict, attempt: int,
                           prior_challenger_args: list[str] | None = None,
                           prior_defender_args: list[str] | None = None) -> dict:
    """One full debate round: challenger -> defender -> adjudicator.
    On reruns (attempt > 1), each agent is shown its own prior arguments and
    explicitly instructed not to repeat them — so every rerun argues something new."""
    DEBATE_ROUNDS_TOTAL.inc()
    challenger = _run_challenger(transaction, evidence, attempt, case_id=case_id,
                                  prior_arguments=prior_challenger_args)
    append_event("agent", "challenger", f"Challenger argument (attempt {attempt})",
                 {"confidence": challenger["confidence"], "argument": challenger["argument"][:200]},
                 case_id=case_id)

    defender = _run_defender(transaction, evidence, attempt, case_id=case_id,
                             prior_arguments=prior_defender_args)
    append_event("agent", "defender", f"Defender argument (attempt {attempt})",
                 {"confidence": defender["confidence"], "argument": defender["argument"][:200]},
                 case_id=case_id)

    adjudication = _run_adjudicator(transaction, evidence, challenger, defender, attempt, case_id=case_id)
    append_event("agent", "adjudicator", f"Adjudication (attempt {attempt})",
                 {"risk": adjudication["risk"], "confidence": adjudication["confidence"],
                  "disposition": adjudication["disposition"]},
                 case_id=case_id)

    return {"attempt": attempt, "challenger": challenger, "defender": defender,
            "adjudication": adjudication}


@traceable(name="run_pipeline_for_case", run_type="chain")
async def run_pipeline_for_case(case_id: str) -> dict:
    """
    Phase 1 -> Phase 2 (with re-run loop, max debate_round_cap re-runs = up to
    debate_round_cap+1 total attempts) -> Phase 3 confidence gate -> routing.

    Returns the final case state including routing decision.
    """
    settings = get_settings()
    now = datetime.now(timezone.utc).isoformat()

    with get_db() as conn:
        case_row = conn.execute("SELECT * FROM cases WHERE id=?", (case_id,)).fetchone()
        if not case_row:
            raise ValueError(f"Case {case_id} not found")
        txn_row = conn.execute(
            "SELECT * FROM transactions WHERE id=?", (case_row["transaction_id"],)
        ).fetchone()

    transaction = dict(txn_row)
    flags = json.loads(transaction["flags"] or "[]")

    with get_db() as conn:
        conn.execute("UPDATE cases SET status=? WHERE id=?", ("collecting_evidence", case_id))
    append_event("system", "pipeline", "Phase 1 — evidence collection started", {}, case_id=case_id)

    # ---- Phase 1: Evidence ----
    evidence = await collect_evidence(transaction, flags, case_id=case_id)
    with get_db() as conn:
        conn.execute("UPDATE cases SET evidence=?, status=? WHERE id=?",
                    (json.dumps(evidence), "agent_debate", case_id))
    append_event("agent", "evidence-agent", "Evidence collected",
                 {"policy_confidence": evidence["policy_analysis"]["confidence"]}, case_id=case_id)

    # ---- Phase 2: Debate (with re-run loop) ----
    debate_history = []
    attempt = 1
    max_attempts = settings.max_debate_attempts  # hard cap: 3 by default

    while attempt <= max_attempts:
        prior_challenger_args = [r["challenger"]["argument"] for r in debate_history]
        prior_defender_args = [r["defender"]["argument"] for r in debate_history]

        round_result = await run_debate_round(
            case_id, transaction, evidence, attempt,
            prior_challenger_args=prior_challenger_args or None,
            prior_defender_args=prior_defender_args or None,
        )
        debate_history.append(round_result)
        confidence = round_result["adjudication"]["confidence"]

        if confidence >= settings.confidence_review_low:
            break  # confident enough — exit re-run loop, proceed to gate

        if attempt < max_attempts:
            append_event("system", "pipeline",
                         f"Confidence {confidence} < {settings.confidence_review_low} — re-running debate",
                         {"attempt": attempt, "confidence": confidence}, case_id=case_id)
            attempt += 1
        else:
            break  # exhausted re-runs, proceed to gate with low confidence

    final_round = debate_history[-1]
    adjudication = final_round["adjudication"]
    confidence = adjudication["confidence"]
    risk = adjudication["risk"]
    total_attempts = len(debate_history)
    # Hit the attempt cap at all (3 by default) -> force manual review, REGARDLESS
    # of what the final confidence/risk happened to land on. Hitting the cap means
    # the agents never converged cleanly within the allowed re-runs, so a human
    # has to look at it no matter how the last attempt's numbers came out.
    rerun_exhausted = total_attempts >= max_attempts

    with get_db() as conn:
        conn.execute(
            """UPDATE cases SET challenger_view=?, defender_view=?, adjudication=?,
               confidence=?, risk=?, disposition=?, attempt_count=?, debate_history=?
               WHERE id=?""",
            (json.dumps(final_round["challenger"]), json.dumps(final_round["defender"]),
             json.dumps(adjudication), confidence, risk, adjudication["disposition"],
             total_attempts, json.dumps(debate_history), case_id),
        )

    # ---- Phase 3: Confidence gate — THREE INDEPENDENT PATHS ----
    escalation_reason = ""

    if rerun_exhausted:
        routing = "manual"
        escalation_reason = "debate_attempts_exhausted"
        append_event("system", "pipeline", "Forced escalation — used all 3 debate attempts without early resolution",
                     {"attempts": total_attempts, "max_attempts": max_attempts, "final_confidence": confidence,
                      "escalation_reason": escalation_reason}, case_id=case_id)

    elif confidence >= settings.confidence_auto_clear and risk in ("low", "cleared"):
        routing = "auto_clear"

    elif confidence >= settings.confidence_review_low:
        if risk in ("high", "critical"):
            routing = "manual"
            escalation_reason = "high_risk_despite_confidence"
            append_event("system", "pipeline", "Forced escalation — risk too high for auto-routing",
                         {"risk": risk, "confidence": confidence,
                          "escalation_reason": escalation_reason}, case_id=case_id)
        else:
            routing = "review"  # goes straight to report — no human interrupt

    else:
        routing = "manual"  # risk-driven manual (e.g. critical risk despite passable confidence)

    with get_db() as conn:
        conn.execute(
            "UPDATE cases SET routing=?, escalation_reason=?, status=?, updated_at=? WHERE id=?",
            (routing, escalation_reason,
             "pending_human_review" if routing == "manual" else "report_ready",
             now, case_id),
        )

    append_event("system", "pipeline", f"Confidence gate routed case to: {routing}",
                 {"routing": routing, "confidence": confidence, "risk": risk,
                  "escalation_reason": escalation_reason}, case_id=case_id)
    CASE_ROUTING_TOTAL.labels(routing=routing).inc()

    # auto_clear and review go DIRECTLY to report — no human step
    if routing in ("auto_clear", "review"):
        await _generate_report(case_id, routing, risk, confidence, adjudication, human_reviewed=False)

    return {
        "case_id": case_id, "routing": routing, "risk": risk, "confidence": confidence,
        "attempts": total_attempts, "escalation_reason": escalation_reason,
        "requires_human_review": routing == "manual",
    }


async def _generate_report(case_id: str, routing: str, risk: str, confidence: float,
                           adjudication: dict, human_reviewed: bool) -> str:
    import uuid
    now = datetime.now(timezone.utc).isoformat()
    report_id = f"RPT-{uuid.uuid4().hex[:8].upper()}"
    with get_db() as conn:
        conn.execute(
            """INSERT INTO reports (id,case_id,routing,risk,confidence,summary,citations,human_reviewed,created_at)
               VALUES (?,?,?,?,?,?,?,?,?)""",
            (report_id, case_id, routing, risk, confidence,
             adjudication.get("summary", ""), json.dumps([]), int(human_reviewed), now),
        )
        conn.execute("UPDATE cases SET status=? WHERE id=?", ("report_ready", case_id))
    append_event("system", "pipeline", "Report generated",
                 {"report_id": report_id, "routing": routing, "human_reviewed": human_reviewed},
                 case_id=case_id)
    return report_id


async def submit_human_review(case_id: str, actor: str, action: str, comment: str, signature: str) -> dict:
    """
    Human review — ONLY reachable for routing='manual' (forced escalation).
    Review queue cases never call this endpoint.
    """
    import uuid
    now = datetime.now(timezone.utc).isoformat()

    with get_db() as conn:
        case_row = conn.execute("SELECT * FROM cases WHERE id=?", (case_id,)).fetchone()
        if not case_row:
            raise ValueError(f"Case {case_id} not found")
        if case_row["routing"] != "manual":
            raise ValueError(
                f"Case {case_id} has routing='{case_row['routing']}' — only 'manual' "
                f"(forced escalation) cases require human review."
            )
        txn_row = conn.execute(
            "SELECT posted_by FROM transactions WHERE id=?", (case_row["transaction_id"],)
        ).fetchone()

    # Segregation of duties enforcement
    if txn_row and txn_row["posted_by"] and actor.lower() == txn_row["posted_by"].lower():
        raise ValueError("SOD violation: reviewer cannot be the same person who posted the transaction.")

    review_id = f"REV-{uuid.uuid4().hex[:8].upper()}"
    with get_db() as conn:
        conn.execute(
            """INSERT INTO reviews (id,case_id,queue,actor,action,comment,signature,created_at)
               VALUES (?,?,?,?,?,?,?,?)""",
            (review_id, case_id, "manual", actor, action, comment, signature, now),
        )
    append_event("human", actor, f"Human review decision: {action}",
                 {"comment": comment, "signature": signature}, case_id=case_id)

    adjudication = json.loads(case_row["adjudication"] or "{}")
    await _generate_report(case_id, "manual", case_row["risk"], case_row["confidence"],
                           adjudication, human_reviewed=True)

    return {"review_id": review_id, "case_id": case_id, "action": action, "status": "report_ready"}
