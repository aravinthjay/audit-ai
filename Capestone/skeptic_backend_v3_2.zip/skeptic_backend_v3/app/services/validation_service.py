"""app/services/validation_service.py — Phase 1b: third-party validation.

Once classify_transaction() says what kind of expense this is, this module
validates it against the real-world facts a category implies:
  - flight / train: is there a PNR in the description, and does it match the
    expected format? (optionally verified against a live PNR-lookup provider)
  - hotel / restaurant: is the GST number well-formed? (optionally verified
    against a live GSTIN-verification provider)
  - all travel/food categories: is the claimed amount within
    VALIDATION_DEVIATION_THRESHOLD_PCT of a live or fallback benchmark rate?

Exactly like the existing FX check in evidence_service.py, every live-provider
call degrades gracefully to a local fallback (format regex / static benchmark
table) if no provider URL is configured or the provider is unreachable — this
app never blocks or fails a case just because an optional third-party
verification source is down.
"""
from __future__ import annotations
import re
import httpx

from app.core.config import get_settings

_TIMEOUT = 6.0

FLIGHT_PNR_RE = re.compile(r"\b([A-Z0-9]{6})\b")          # 6-char alphanumeric IATA PNR
TRAIN_PNR_RE = re.compile(r"\b(\d{10})\b")                 # 10-digit IRCTC PNR
GSTIN_RE = re.compile(r"^\d{2}[A-Z]{5}\d{4}[A-Z]\dZ[A-Z\d]$")

# Fallback static benchmarks (USD) used when no live benchmark provider is
# configured. These are deliberately conservative placeholders — replace via
# TRAVEL_BENCHMARK_API_URL for real production rates.
_FALLBACK_BENCHMARKS_USD = {
    "flight": 180.0,
    "train": 25.0,
    "bus": 15.0,
    "hotel": 90.0,       # per stay, not per night — coarse fallback
    "restaurant": 35.0,
}


_PNR_LABEL_RE = re.compile(r"\bPNR\b[\s:#-]*([A-Z0-9]{6,10})", re.I)
_MIXED_ALNUM_RE = re.compile(r"\b(?=[A-Z]*\d)(?=\d*[A-Z])[A-Z0-9]{6}\b")  # must contain both a letter and a digit


def _extract_pnr(description: str, category: str) -> str | None:
    text = description.upper()

    # Prefer an explicit "PNR <code>" label if present.
    m = _PNR_LABEL_RE.search(text)
    if m:
        code = m.group(1)
        if category == "train" and code.isdigit() and len(code) == 10:
            return code
        if category == "flight" and len(code) == 6:
            return code

    if category == "flight":
        # Fall back to any 6-char token that mixes letters and digits (real
        # PNRs do; plain English words like "FLIGHT" or "TICKET" don't).
        m2 = _MIXED_ALNUM_RE.search(text)
        return m2.group(0) if m2 else None
    if category == "train":
        m2 = TRAIN_PNR_RE.search(description)
        return m2.group(1) if m2 else None
    return None


async def _verify_pnr_live(pnr: str, category: str) -> dict | None:
    settings = get_settings()
    if not settings.pnr_verification_api_url:
        return None
    try:
        async with httpx.AsyncClient(timeout=_TIMEOUT) as client:
            r = await client.get(settings.pnr_verification_api_url, params={"pnr": pnr, "type": category})
            r.raise_for_status()
            return r.json()
    except Exception:
        return None


async def _verify_gstin_live(gstin: str) -> dict | None:
    settings = get_settings()
    if not settings.gst_verification_api_url:
        return None
    try:
        async with httpx.AsyncClient(timeout=_TIMEOUT) as client:
            r = await client.get(settings.gst_verification_api_url, params={"gstin": gstin})
            r.raise_for_status()
            return r.json()
    except Exception:
        return None


async def _get_benchmark_usd(category: str) -> tuple[float, str]:
    """Returns (benchmark_usd, source) where source is 'live' or 'fallback_static'."""
    settings = get_settings()
    if settings.travel_benchmark_api_url:
        try:
            async with httpx.AsyncClient(timeout=_TIMEOUT) as client:
                r = await client.get(settings.travel_benchmark_api_url, params={"category": category})
                r.raise_for_status()
                data = r.json()
                if "benchmark_usd" in data:
                    return float(data["benchmark_usd"]), "live"
        except Exception:
            pass
    return _FALLBACK_BENCHMARKS_USD.get(category, 50.0), "fallback_static"


def _validate_pnr_format(pnr: str | None, category: str) -> bool:
    if pnr is None:
        return False
    if category == "flight":
        return bool(FLIGHT_PNR_RE.fullmatch(pnr))
    if category == "train":
        return bool(TRAIN_PNR_RE.fullmatch(pnr))
    return True


async def validate_transaction(category: str, transaction: dict) -> dict:
    """
    Returns a dict consumed directly by the debate agents:
      {
        "category": ..., "checks": {...}, "amount_deviation_pct": float|None,
        "benchmark_usd": float|None, "benchmark_source": "live"|"fallback_static"|None,
        "valid": bool, "reasons": [str, ...]
      }
    `valid` is True only if every applicable check (PNR/GST format or live
    verification, and the amount staying within the deviation threshold)
    passes. Any failure is captured in `reasons` and flows into evidence for
    the challenger/defender to argue over.
    """
    settings = get_settings()
    description = transaction.get("description", "")
    gst_number = (transaction.get("gst_number") or "").strip().upper()
    amount_usd = float(transaction.get("amount_usd", 0) or 0)

    checks: dict = {}
    reasons: list[str] = []
    valid = True

    # --- PNR check (flight / train only) ---
    if category in ("flight", "train"):
        pnr = _extract_pnr(description, category)
        format_ok = _validate_pnr_format(pnr, category)
        live_result = await _verify_pnr_live(pnr, category) if pnr else None
        checks["pnr"] = {
            "extracted_pnr": pnr, "format_valid": format_ok,
            "live_verification": live_result,
        }
        if not pnr:
            valid = False
            reasons.append(f"No PNR found in description for a {category} expense.")
        elif not format_ok:
            valid = False
            reasons.append(f"PNR '{pnr}' does not match expected {category} PNR format.")

    # --- GSTIN check (hotel / restaurant only) ---
    if category in ("hotel", "restaurant"):
        format_ok = bool(GSTIN_RE.fullmatch(gst_number)) if gst_number else False
        live_result = await _verify_gstin_live(gst_number) if gst_number else None
        checks["gstin"] = {
            "gst_number": gst_number or None, "format_valid": format_ok,
            "live_verification": live_result,
        }
        if not gst_number:
            valid = False
            reasons.append(f"No GST number present for a {category} expense.")
        elif not format_ok:
            valid = False
            reasons.append(f"GST number '{gst_number}' is not a well-formed GSTIN.")

    # --- Amount vs benchmark/live rate (all travel/food categories) ---
    benchmark_usd, benchmark_source = (None, None)
    deviation_pct = None
    if category in _FALLBACK_BENCHMARKS_USD:
        benchmark_usd, benchmark_source = await _get_benchmark_usd(category)
        deviation_pct = round((amount_usd - benchmark_usd) / max(benchmark_usd, 0.01) * 100, 2)
        checks["amount_benchmark"] = {
            "claimed_usd": amount_usd, "benchmark_usd": benchmark_usd,
            "source": benchmark_source, "deviation_pct": deviation_pct,
        }
        if deviation_pct > settings.validation_deviation_threshold_pct:
            valid = False
            reasons.append(
                f"Claimed amount ${amount_usd:.2f} is {deviation_pct:.1f}% above the "
                f"{benchmark_source} {category} benchmark (${benchmark_usd:.2f})."
            )

    return {
        "category": category,
        "checks": checks,
        "amount_deviation_pct": deviation_pct,
        "benchmark_usd": benchmark_usd,
        "benchmark_source": benchmark_source,
        "valid": valid,
        "reasons": reasons,
    }
