"""app/services/audit_log_service.py
Append-only, hash-chained audit log. Every pipeline event — system, agent,
human, source — is appended here. Never updated, never deleted.
"""
from __future__ import annotations
import hashlib
import json
import uuid
from datetime import datetime, timezone

from app.core.telemetry import get_current_run_id
from app.db.database import get_db

GENESIS_HASH = "0" * 64


def _compute_hash(payload: dict) -> str:
    canonical = json.dumps(payload, sort_keys=True, default=str)
    return hashlib.sha256(canonical.encode()).hexdigest()


def _get_last_hash(case_id: str | None = None) -> str:
    with get_db() as conn:
        if case_id:
            row = conn.execute(
                "SELECT hash FROM audit_log WHERE case_id=? ORDER BY created_at DESC LIMIT 1",
                (case_id,),
            ).fetchone()
        else:
            row = conn.execute(
                "SELECT hash FROM audit_log ORDER BY created_at DESC LIMIT 1"
            ).fetchone()
    return row["hash"] if row else GENESIS_HASH


def append_event(
    event_type: str,
    actor: str,
    title: str,
    detail: dict,
    case_id: str | None = None,
) -> dict:
    """Append one event to the hash chain. Returns the stored entry."""
    now = datetime.now(timezone.utc).isoformat()
    prev_hash = _get_last_hash(case_id)
    entry_id = f"LOG-{uuid.uuid4().hex[:10].upper()}"
    langsmith_run_id = get_current_run_id()

    payload = {
        "id": entry_id, "case_id": case_id, "event_type": event_type,
        "actor": actor, "title": title, "detail": detail,
        "prev_hash": prev_hash, "created_at": now,
    }
    entry_hash = _compute_hash(payload)

    with get_db() as conn:
        conn.execute(
            """INSERT INTO audit_log
               (id, case_id, event_type, actor, title, detail, prev_hash, hash, langsmith_run_id, created_at)
               VALUES (?,?,?,?,?,?,?,?,?,?)""",
            (entry_id, case_id, event_type, actor, title,
             json.dumps(detail), prev_hash, entry_hash, langsmith_run_id, now),
        )
    payload["hash"] = entry_hash
    payload["langsmith_run_id"] = langsmith_run_id
    return payload


def get_case_log(case_id: str) -> list[dict]:
    with get_db() as conn:
        rows = conn.execute(
            "SELECT * FROM audit_log WHERE case_id=? ORDER BY created_at ASC", (case_id,)
        ).fetchall()
    return [
        {**dict(r), "detail": json.loads(r["detail"] or "{}")}
        for r in rows
    ]


def verify_chain(case_id: str) -> dict:
    """Recompute hashes and verify the chain is unbroken for one case."""
    entries = get_case_log(case_id)
    if not entries:
        return {"valid": True, "checked": 0, "broken_at": None}

    for i, entry in enumerate(entries):
        payload = {
            "id": entry["id"], "case_id": entry["case_id"],
            "event_type": entry["event_type"], "actor": entry["actor"],
            "title": entry["title"], "detail": entry["detail"],
            "prev_hash": entry["prev_hash"], "created_at": entry["created_at"],
        }
        recomputed = _compute_hash(payload)
        if recomputed != entry["hash"]:
            return {"valid": False, "checked": i + 1, "broken_at": entry["id"]}
        if i > 0 and entry["prev_hash"] != entries[i - 1]["hash"]:
            return {"valid": False, "checked": i + 1, "broken_at": entry["id"]}

    return {"valid": True, "checked": len(entries), "broken_at": None}
