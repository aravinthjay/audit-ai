"""app/services/intake_service.py — Phase 0: ingest, clean, flag."""
from __future__ import annotations
import csv
import io
import json
import re
import uuid
from datetime import datetime, timezone

from app.core.config import get_settings
from app.db.database import get_db
from app.services.audit_log_service import append_event

KNOWN_VENDORS = {
    "amazon", "aws", "microsoft", "google", "dhl", "fedex", "uber", "ola",
    "makemytrip", "oyo", "airbnb", "reliance", "tata", "infosys", "wipro",
    "hdfc", "icici", "indigo", "air india", "irctc", "zomato", "swiggy",
    "dell", "hp india", "lenovo", "bluedart", "dtdc", "jio", "airtel",
    "linkedin", "facebook", "godrej", "dlf", "brigade", "pidilite",
    "3m", "canon", "xerox", "staples", "times", "bsnl",
}


def _clean_amount(raw: str) -> float | None:
    try:
        cleaned = re.sub(r"[₹$€£,\s]", "", str(raw).strip())
        return float(cleaned) if cleaned else None
    except (ValueError, TypeError):
        return None


def _clean_date(raw: str) -> str:
    raw = raw.strip()
    for fmt in ["%Y-%m-%dT%H:%M:%SZ", "%Y-%m-%d %H:%M:%S", "%Y-%m-%d", "%d/%m/%Y"]:
        try:
            dt = datetime.strptime(raw, fmt)
            return dt.isoformat()
        except ValueError:
            continue
    return raw


def _is_round_number(amount: float) -> bool:
    return re.search(r"(000|500)$", str(int(amount))) is not None


def _is_off_hours(date_str: str) -> bool:
    try:
        dt = datetime.fromisoformat(date_str.replace("Z", "+00:00"))
        return dt.hour not in range(8, 20)
    except Exception:
        return False


def _is_unknown_vendor(vendor: str) -> bool:
    v = vendor.lower()
    return not any(k in v for k in KNOWN_VENDORS)


def _apply_flags(row: dict, settings, seen: set) -> list[str]:
    flags = []
    amt, cur, fx = row["amount_usd"], row["currency"], row["fx_rate"]
    posted_by, vendor, date_str = row["posted_by"], row["vendor"], row["posted_at"]

    if amt >= settings.materiality_threshold:
        flags.append("materiality")
    if cur != "USD" and (fx < 0.0001 or fx > 1000):
        flags.append("fx-outlier")
    if _is_round_number(amt) and amt < settings.materiality_threshold:
        flags.append("round-number")
    if posted_by and posted_by.lower() in vendor.lower():
        flags.append("segregation-of-duties")
    dk = f"{vendor.lower()}|{amt}|{date_str[:10]}"
    if dk in seen:
        flags.append("duplicate")
    seen.add(dk)
    if _is_unknown_vendor(vendor):
        flags.append("unknown-vendor")
    if date_str and _is_off_hours(date_str):
        flags.append("off-hours")
    return flags


async def parse_and_flag_csv(content: bytes, filename: str) -> dict:
    settings = get_settings()
    try:
        text = content.decode("utf-8-sig")
    except UnicodeDecodeError:
        text = content.decode("latin-1")

    rows = list(csv.DictReader(io.StringIO(text)))
    flagged, cleared = [], []
    parse_errors = 0
    seen: set[str] = set()
    rule_counts = {k: 0 for k in [
        "materiality", "fx-outlier", "round-number",
        "segregation-of-duties", "duplicate", "unknown-vendor", "off-hours",
    ]}
    now = datetime.now(timezone.utc).isoformat()

    with get_db() as conn:
        for row in rows:
            try:
                txn_id = row.get("txn_id", "").strip() or f"TXN-{uuid.uuid4().hex[:6].upper()}"
                vendor = " ".join(row.get("vendor", "Unknown").split())
                account = row.get("account", "").strip()
                currency = row.get("currency", "USD").strip().upper() or "USD"
                posted_by = row.get("posted_by", "").strip()
                description = row.get("description", "").strip()
                gst_number = row.get("gst_number", "").strip()
                posted_at = _clean_date(row.get("date", ""))

                amount_usd = _clean_amount(row.get("amount_usd", row.get("amount", "0")))
                if amount_usd is None:
                    parse_errors += 1
                    continue
                fx_rate = _clean_amount(row.get("fx_rate", "1.0")) or 1.0
                amount = _clean_amount(row.get("amount", str(amount_usd))) or amount_usd

                row_data = {"amount_usd": amount_usd, "currency": currency,
                            "fx_rate": fx_rate, "posted_by": posted_by,
                            "vendor": vendor, "posted_at": posted_at}
                flags = _apply_flags(row_data, settings, seen)
                for f in flags:
                    rule_counts[f] += 1

                tid = f"TXN-{uuid.uuid4().hex[:8].upper()}"
                is_flagged = len(flags) > 0

                conn.execute(
                    """INSERT INTO transactions
                       (id,txn_id,vendor,account,amount,currency,amount_usd,fx_rate,
                        posted_by,posted_at,description,gst_number,flags,flag_count,
                        is_flagged,status,source_file,created_at)
                       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (tid, txn_id, vendor, account, amount, currency, amount_usd, fx_rate,
                     posted_by, posted_at, description, gst_number, json.dumps(flags),
                     len(flags), int(is_flagged),
                     "flagged" if is_flagged else "cleared", filename, now),
                )

                record = {
                    "transaction_id": tid, "txn_id": txn_id, "vendor": vendor,
                    "account": account, "amount_usd": amount_usd, "currency": currency,
                    "flags": flags, "is_flagged": is_flagged,
                }

                if is_flagged:
                    case_id = f"CASE-{uuid.uuid4().hex[:8].upper()}"
                    conn.execute(
                        """INSERT INTO cases (id,transaction_id,status,created_at,updated_at)
                           VALUES (?,?,?,?,?)""",
                        (case_id, tid, "intake", now, now),
                    )
                    record["case_id"] = case_id
                    flagged.append(record)
                    append_event("system", "intake-service", "Case created — flagged transaction",
                                 {"txn_id": txn_id, "vendor": vendor, "flags": flags,
                                  "amount_usd": amount_usd}, case_id=case_id)
                else:
                    cleared.append(record)

            except Exception:
                parse_errors += 1

    tone = {"materiality": "danger", "unknown-vendor": "danger",
            "segregation-of-duties": "danger", "fx-outlier": "warning",
            "round-number": "warning", "duplicate": "info", "off-hours": "info"}
    rule_stats = [{"rule": k, "count": v, "tone": tone[k]} for k, v in rule_counts.items() if v > 0]

    append_event("system", "intake-service", "CSV ingested",
                 {"filename": filename, "total_rows": len(rows),
                  "flagged": len(flagged), "cleared": len(cleared)})

    return {
        "file_name": filename, "total_rows": len(rows),
        "flagged_count": len(flagged), "cleared_count": len(cleared),
        "parse_errors": parse_errors, "rules_triggered": rule_stats,
        "flagged_cases": flagged, "cleared_transactions": cleared,
    }
