"""app/services/token_usage_service.py
Persists token usage for every Groq LLM call (challenger, defender,
adjudicator, RAG query, RAG eval) so spend and consumption can be audited
per-case, per-agent, or in aggregate. Also feeds the Prometheus counters.
"""
from __future__ import annotations
import uuid
from datetime import datetime, timezone

from app.core.config import get_settings
from app.core.telemetry import record_token_usage, get_current_run_id
from app.db.database import get_db


def log_token_usage(
    agent: str,
    model: str,
    prompt_tokens: int,
    completion_tokens: int,
    latency_ms: float,
    case_id: str | None = None,
) -> dict:
    settings = get_settings()
    total_tokens = prompt_tokens + completion_tokens
    cost_usd = round(
        (prompt_tokens / 1000.0) * settings.cost_per_1k_prompt_tokens
        + (completion_tokens / 1000.0) * settings.cost_per_1k_completion_tokens,
        8,
    )
    run_id = get_current_run_id()
    now = datetime.now(timezone.utc).isoformat()
    usage_id = f"TOK-{uuid.uuid4().hex[:10].upper()}"

    with get_db() as conn:
        conn.execute(
            """INSERT INTO token_usage
               (id, case_id, agent, model, prompt_tokens, completion_tokens,
                total_tokens, estimated_cost_usd, latency_ms, langsmith_run_id, created_at)
               VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
            (usage_id, case_id, agent, model, prompt_tokens, completion_tokens,
             total_tokens, cost_usd, latency_ms, run_id, now),
        )

    record_token_usage(agent, model, prompt_tokens, completion_tokens, cost_usd)

    return {
        "id": usage_id, "case_id": case_id, "agent": agent, "model": model,
        "prompt_tokens": prompt_tokens, "completion_tokens": completion_tokens,
        "total_tokens": total_tokens, "estimated_cost_usd": cost_usd,
        "latency_ms": latency_ms, "langsmith_run_id": run_id,
    }


def list_usage(case_id: str | None = None, agent: str | None = None, limit: int = 100) -> list[dict]:
    q = "SELECT * FROM token_usage WHERE 1=1"
    params: list = []
    if case_id:
        q += " AND case_id=?"; params.append(case_id)
    if agent:
        q += " AND agent=?"; params.append(agent)
    q += " ORDER BY created_at DESC LIMIT ?"; params.append(limit)
    with get_db() as conn:
        rows = conn.execute(q, params).fetchall()
    return [dict(r) for r in rows]


def usage_summary() -> dict:
    with get_db() as conn:
        rows = conn.execute(
            """SELECT agent, model,
                      SUM(prompt_tokens) AS prompt_tokens,
                      SUM(completion_tokens) AS completion_tokens,
                      SUM(total_tokens) AS total_tokens,
                      SUM(estimated_cost_usd) AS estimated_cost_usd,
                      COUNT(*) AS call_count,
                      AVG(latency_ms) AS avg_latency_ms
               FROM token_usage GROUP BY agent, model"""
        ).fetchall()
        totals = conn.execute(
            """SELECT SUM(prompt_tokens) AS prompt_tokens,
                      SUM(completion_tokens) AS completion_tokens,
                      SUM(total_tokens) AS total_tokens,
                      SUM(estimated_cost_usd) AS estimated_cost_usd,
                      COUNT(*) AS call_count
               FROM token_usage"""
        ).fetchone()
    return {
        "by_agent_model": [dict(r) for r in rows],
        "totals": dict(totals) if totals else {},
    }
