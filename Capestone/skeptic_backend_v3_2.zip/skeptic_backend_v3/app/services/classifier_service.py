"""app/services/classifier_service.py — Phase 1a: transaction category classifier.

Runs BEFORE the third-party validation step so we know which validator
(flight / train / bus / hotel / restaurant / other) applies. Rule-based
keyword matching handles the obvious cases for free and instantly; only
genuinely ambiguous rows fall through to an LLM call (logged + traced like
every other LLM call in this app).
"""
from __future__ import annotations
import re
import time

from groq import Groq
from langsmith import traceable

from app.core.config import get_settings
from app.services.token_usage_service import log_token_usage

CATEGORIES = ["flight", "train", "bus", "hotel", "restaurant", "other"]
CLASSIFIER_MODEL = "llama-3.1-8b-instant"

_RULES = [
    ("flight", re.compile(r"\b(indigo|air india|spicejet|vistara|airlines?|airways|flight|pnr)\b", re.I)),
    ("train", re.compile(r"\b(irctc|railway|train|rajdhani|shatabdi)\b", re.I)),
    ("bus", re.compile(r"\b(redbus|bus|volvo travels|sleeper coach)\b", re.I)),
    ("hotel", re.compile(r"\b(hotel|oyo|airbnb|resort|inn\b|lodging|room night)\b", re.I)),
    ("restaurant", re.compile(r"\b(restaurant|cafe|zomato|swiggy|food\s?court|dining|eatery)\b", re.I)),
]


def _rule_based_guess(vendor: str, description: str) -> str | None:
    text = f"{vendor} {description}"
    for category, pattern in _RULES:
        if pattern.search(text):
            return category
    return None


@traceable(name="classify_transaction", run_type="chain")
def classify_transaction(transaction: dict, case_id: str | None = None) -> dict:
    """Returns {"category": str, "method": "rule"|"llm", "confidence": float}."""
    vendor = transaction.get("vendor", "")
    description = transaction.get("description", "")

    guess = _rule_based_guess(vendor, description)
    if guess:
        return {"category": guess, "method": "rule", "confidence": 0.95}

    # Ambiguous — fall back to an LLM classification call.
    settings = get_settings()
    client = Groq(api_key=settings.groq_api_key)
    prompt = (
        f"Vendor: {vendor}\nDescription: {description}\n\n"
        f"Classify this expense transaction into exactly one category from: "
        f"{', '.join(CATEGORIES)}. Respond with only the category word, nothing else."
    )
    start = time.perf_counter()
    resp = client.chat.completions.create(
        model=CLASSIFIER_MODEL, max_tokens=10, temperature=0.0,
        messages=[
            {"role": "system", "content": "You are an expense transaction classifier. Respond with exactly one word."},
            {"role": "user", "content": prompt},
        ],
    )
    latency_ms = (time.perf_counter() - start) * 1000
    usage = getattr(resp, "usage", None)
    log_token_usage("classifier", CLASSIFIER_MODEL,
                     getattr(usage, "prompt_tokens", 0) or 0,
                     getattr(usage, "completion_tokens", 0) or 0,
                     latency_ms, case_id=case_id)

    raw = resp.choices[0].message.content.strip().lower()
    category = next((c for c in CATEGORIES if c in raw), "other")
    return {"category": category, "method": "llm", "confidence": 0.7}
