"""app/db/database.py — SQLite, 5 tables, hash-chained audit log."""
import sqlite3
import threading
from contextlib import contextmanager
from pathlib import Path

DB_PATH = Path("audit_engine.db")
_local = threading.local()

DDL = """
CREATE TABLE IF NOT EXISTS transactions (
    id          TEXT PRIMARY KEY,
    txn_id      TEXT NOT NULL,
    vendor      TEXT NOT NULL,
    account     TEXT NOT NULL,
    amount      REAL NOT NULL,
    currency    TEXT DEFAULT 'USD',
    amount_usd  REAL NOT NULL,
    fx_rate     REAL DEFAULT 1.0,
    posted_by   TEXT,
    posted_at   TEXT,
    description TEXT DEFAULT '',
    gst_number  TEXT DEFAULT '',
    flags       TEXT DEFAULT '[]',
    flag_count  INTEGER DEFAULT 0,
    is_flagged  INTEGER DEFAULT 0,
    status      TEXT DEFAULT 'intake',
    source_file TEXT DEFAULT '',
    created_at  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS cases (
    id                  TEXT PRIMARY KEY,
    transaction_id      TEXT NOT NULL,
    status              TEXT DEFAULT 'intake',
    evidence            TEXT DEFAULT '{}',
    attempt_count       INTEGER DEFAULT 0,
    challenger_view     TEXT DEFAULT '{}',
    defender_view       TEXT DEFAULT '{}',
    adjudication        TEXT DEFAULT '{}',
    confidence           REAL DEFAULT 0.0,
    risk                TEXT DEFAULT 'medium',
    disposition         TEXT DEFAULT '',
    routing             TEXT DEFAULT '',
    escalation_reason   TEXT DEFAULT '',
    debate_history      TEXT DEFAULT '[]',
    created_at          TEXT NOT NULL,
    updated_at          TEXT NOT NULL,
    FOREIGN KEY (transaction_id) REFERENCES transactions(id)
);

CREATE TABLE IF NOT EXISTS reviews (
    id              TEXT PRIMARY KEY,
    case_id         TEXT NOT NULL,
    queue           TEXT NOT NULL,        -- 'manual' only — review queue never reaches here
    actor           TEXT,
    action          TEXT,                 -- approved | rejected | requested_evidence
    comment         TEXT DEFAULT '',
    signature       TEXT DEFAULT '',
    created_at      TEXT NOT NULL,
    FOREIGN KEY (case_id) REFERENCES cases(id)
);

CREATE TABLE IF NOT EXISTS reports (
    id              TEXT PRIMARY KEY,
    case_id         TEXT NOT NULL,
    routing         TEXT NOT NULL,         -- auto_clear | review | manual
    risk            TEXT NOT NULL,
    confidence      REAL NOT NULL,
    summary         TEXT DEFAULT '',
    citations       TEXT DEFAULT '[]',
    human_reviewed  INTEGER DEFAULT 0,
    created_at      TEXT NOT NULL,
    FOREIGN KEY (case_id) REFERENCES cases(id)
);

CREATE TABLE IF NOT EXISTS audit_log (
    id              TEXT PRIMARY KEY,
    case_id         TEXT,
    event_type      TEXT NOT NULL,        -- system | agent | human | source
    actor           TEXT NOT NULL,
    title           TEXT NOT NULL,
    detail          TEXT DEFAULT '{}',
    prev_hash       TEXT NOT NULL,
    hash            TEXT NOT NULL,
    langsmith_run_id TEXT DEFAULT '',
    created_at      TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS token_usage (
    id                  TEXT PRIMARY KEY,
    case_id             TEXT,
    agent               TEXT NOT NULL,     -- challenger | defender | adjudicator | rag-query | rag-eval
    model               TEXT NOT NULL,
    prompt_tokens       INTEGER DEFAULT 0,
    completion_tokens   INTEGER DEFAULT 0,
    total_tokens        INTEGER DEFAULT 0,
    estimated_cost_usd  REAL DEFAULT 0.0,
    latency_ms          REAL DEFAULT 0.0,
    langsmith_run_id    TEXT DEFAULT '',
    created_at          TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS rag_eval (
    id                  TEXT PRIMARY KEY,
    run_id              TEXT NOT NULL,     -- groups multiple questions evaluated together
    query               TEXT NOT NULL,
    expected_answer     TEXT DEFAULT '',
    answer              TEXT DEFAULT '',
    retrieved_chunks    TEXT DEFAULT '[]',
    chunk_scores        TEXT DEFAULT '[]',
    avg_relevance_score REAL DEFAULT 0.0,
    top_relevance_score REAL DEFAULT 0.0,
    relevant_chunk_count INTEGER DEFAULT 0,
    groundedness_score  REAL DEFAULT 0.0,
    keyword_match_score REAL DEFAULT 0.0,
    latency_ms          REAL DEFAULT 0.0,
    created_at          TEXT NOT NULL
);
"""


def _get_conn() -> sqlite3.Connection:
    if not hasattr(_local, "conn") or _local.conn is None:
        conn = sqlite3.connect(str(DB_PATH), check_same_thread=False)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        _local.conn = conn
    return _local.conn


@contextmanager
def get_db():
    conn = _get_conn()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise


def init_db() -> None:
    with get_db() as conn:
        conn.executescript(DDL)
