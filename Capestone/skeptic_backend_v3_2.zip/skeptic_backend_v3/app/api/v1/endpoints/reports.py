"""app/api/v1/endpoints/reports.py"""
import json
from fastapi import APIRouter, HTTPException
from app.db.database import get_db

router = APIRouter(prefix="/reports", tags=["Output - Reports"])


@router.get("")
async def list_reports(routing: str | None = None, limit: int = 50):
    with get_db() as conn:
        if routing:
            rows = conn.execute(
                "SELECT * FROM reports WHERE routing=? ORDER BY created_at DESC LIMIT ?",
                (routing, limit)).fetchall()
        else:
            rows = conn.execute(
                "SELECT * FROM reports ORDER BY created_at DESC LIMIT ?", (limit,)).fetchall()
    return [{**dict(r), "human_reviewed": bool(r["human_reviewed"])} for r in rows]


@router.get("/{case_id}")
async def get_report(case_id: str):
    with get_db() as conn:
        row = conn.execute(
            "SELECT * FROM reports WHERE case_id=? ORDER BY created_at DESC LIMIT 1", (case_id,)
        ).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail=f"No report for case {case_id}")
    return {**dict(row), "human_reviewed": bool(row["human_reviewed"])}
