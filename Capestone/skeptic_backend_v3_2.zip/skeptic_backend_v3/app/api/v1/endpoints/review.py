"""app/api/v1/endpoints/review.py — human review, ONLY for routing='manual' cases."""
import json
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from app.db.database import get_db
from app.agents.pipeline import submit_human_review

router = APIRouter(prefix="/review", tags=["Phase 3 - Human Review (manual queue only)"])


class ReviewDecision(BaseModel):
    actor: str
    action: str   # approved | rejected | requested_evidence
    comment: str = ""
    signature: str = ""


@router.get("/queue")
async def get_manual_queue():
    """List cases waiting for human review — only routing='manual' (forced escalation) cases appear here."""
    with get_db() as conn:
        rows = conn.execute(
            "SELECT c.*, t.txn_id, t.vendor, t.amount_usd, t.posted_by FROM cases c "
            "JOIN transactions t ON t.id = c.transaction_id "
            "WHERE c.routing='manual' AND c.status='pending_human_review' "
            "ORDER BY c.updated_at ASC"
        ).fetchall()
    return [{**dict(r)} for r in rows]


@router.post("/{case_id}/decide")
async def decide(case_id: str, decision: ReviewDecision):
    """Submit a human decision for a forced-escalation case. Enforces SOD."""
    try:
        return await submit_human_review(
            case_id, decision.actor, decision.action, decision.comment, decision.signature
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.get("/{case_id}/history")
async def review_history(case_id: str):
    with get_db() as conn:
        rows = conn.execute(
            "SELECT * FROM reviews WHERE case_id=? ORDER BY created_at ASC", (case_id,)
        ).fetchall()
    return [dict(r) for r in rows]
