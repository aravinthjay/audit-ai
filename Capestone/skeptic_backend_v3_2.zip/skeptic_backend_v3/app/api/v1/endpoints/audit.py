"""app/api/v1/endpoints/audit.py — append-only hash-chained log."""
from fastapi import APIRouter, HTTPException
from app.services.audit_log_service import get_case_log, verify_chain
from app.db.database import get_db

router = APIRouter(prefix="/audit", tags=["Output - Audit log"])


@router.get("")
async def full_log(limit: int = 100):
    with get_db() as conn:
        rows = conn.execute(
            "SELECT * FROM audit_log ORDER BY created_at DESC LIMIT ?", (limit,)
        ).fetchall()
    import json
    return [{**dict(r), "detail": json.loads(r["detail"] or "{}")} for r in rows]


@router.get("/{case_id}")
async def case_log(case_id: str):
    log = get_case_log(case_id)
    if not log:
        raise HTTPException(status_code=404, detail=f"No audit log for case {case_id}")
    return log


@router.get("/{case_id}/verify")
async def verify(case_id: str):
    """Recompute the hash chain and confirm no tampering occurred."""
    return verify_chain(case_id)
