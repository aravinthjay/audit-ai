"""app/api/v1/endpoints/cases.py — Phase 1-3: evidence, debate, gate, routing"""
import json
from fastapi import APIRouter, HTTPException
from app.db.database import get_db
from app.agents.pipeline import run_pipeline_for_case

router = APIRouter(prefix="/cases", tags=["Phase 1-3 - Pipeline"])


@router.get("")
async def list_cases(status: str | None = None, routing: str | None = None, limit: int = 50):
    with get_db() as conn:
        q = "SELECT c.*, t.txn_id, t.vendor, t.amount_usd, t.flags FROM cases c JOIN transactions t ON t.id = c.transaction_id WHERE 1=1"
        params = []
        if status:
            q += " AND c.status=?"; params.append(status)
        if routing:
            q += " AND c.routing=?"; params.append(routing)
        q += " ORDER BY c.created_at DESC LIMIT ?"; params.append(limit)
        rows = conn.execute(q, params).fetchall()
    return [{**dict(r), "flags": json.loads(r["flags"] or "[]")} for r in rows]


@router.get("/{case_id}")
async def get_case(case_id: str):
    with get_db() as conn:
        row = conn.execute(
            "SELECT c.*, t.txn_id, t.vendor, t.amount_usd, t.currency, t.flags, t.posted_by "
            "FROM cases c JOIN transactions t ON t.id = c.transaction_id WHERE c.id=?",
            (case_id,)).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail=f"Case {case_id} not found")
    d = dict(row)
    for f in ["flags", "evidence", "challenger_view", "defender_view", "adjudication", "debate_history"]:
        d[f] = json.loads(d.get(f) or ("[]" if f in ("flags", "debate_history") else "{}"))
    return d


@router.post("/{case_id}/run")
async def run_case(case_id: str):
    """
    Runs Phase 1 (evidence) -> Phase 2 (debate, with re-run loop) -> Phase 3 (gate).
    auto_clear and review routes complete immediately (report generated, no human).
    manual route (forced escalation) pauses — call POST /review/{case_id}/decide next.
    """
    try:
        return await run_pipeline_for_case(case_id)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Pipeline error: {e}")
