"""app/api/v1/endpoints/tokens.py — token usage / cost audit API."""
from fastapi import APIRouter
from app.services.token_usage_service import list_usage, usage_summary

router = APIRouter(prefix="/tokens", tags=["Output - Token Usage"])


@router.get("/usage")
async def get_usage(case_id: str | None = None, agent: str | None = None, limit: int = 100):
    """Raw per-call token usage rows. Filter by case_id (e.g. CASE-xxxx) or
    agent (challenger | defender | adjudicator | rag-query | rag-eval)."""
    return list_usage(case_id=case_id, agent=agent, limit=limit)


@router.get("/usage/summary")
async def get_usage_summary():
    """Aggregated token counts + estimated USD cost, grouped by agent/model,
    plus a grand total. Mirrors the Prometheus counters skeptic_llm_tokens_total
    and skeptic_llm_cost_usd_total for anyone who wants it without a Grafana setup."""
    return usage_summary()
