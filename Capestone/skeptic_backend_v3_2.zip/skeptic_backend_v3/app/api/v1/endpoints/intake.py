"""app/api/v1/endpoints/intake.py — Phase 0"""
from fastapi import APIRouter, File, HTTPException, UploadFile
from app.services.intake_service import parse_and_flag_csv

router = APIRouter(prefix="/intake", tags=["Phase 0 - Intake"])
_MAX_BYTES = 10 * 1024 * 1024


@router.post("/upload")
async def upload_gl_csv(file: UploadFile = File(...)):
    """Upload GL CSV. Parses, cleans, applies 7 flagging rules. Creates a case per flagged row."""
    if not (file.filename or "").lower().endswith((".csv", ".tsv")):
        raise HTTPException(status_code=400, detail="Only CSV or TSV accepted.")
    content = await file.read()
    if len(content) > _MAX_BYTES:
        raise HTTPException(status_code=413, detail="File too large (max 10MB).")
    try:
        return await parse_and_flag_csv(content, file.filename or "upload.csv")
    except Exception as e:
        raise HTTPException(status_code=422, detail=f"Parse error: {e}")


@router.get("/transactions")
async def list_transactions(status: str | None = None, limit: int = 100):
    import json
    from app.db.database import get_db
    with get_db() as conn:
        if status:
            rows = conn.execute(
                "SELECT * FROM transactions WHERE status=? ORDER BY created_at DESC LIMIT ?",
                (status, limit)).fetchall()
        else:
            rows = conn.execute(
                "SELECT * FROM transactions ORDER BY created_at DESC LIMIT ?", (limit,)).fetchall()
    return [{**dict(r), "flags": json.loads(r["flags"] or "[]")} for r in rows]
