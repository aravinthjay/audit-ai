"""app/api/v1/endpoints/rag.py — standalone RAG query + RAG evaluation API."""
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from app.services.rag_service import (
    answer_policy_question, evaluate_rag, evaluate_rag_batch, list_rag_evals,
)

router = APIRouter(prefix="/rag", tags=["RAG - Query & Evaluation"])


class RagQuery(BaseModel):
    question: str
    case_id: str | None = None


class RagEvalItem(BaseModel):
    query: str
    expected_answer: str = ""


class RagEvalBatch(BaseModel):
    questions: list[RagEvalItem]


@router.post("/query")
async def query_rag(payload: RagQuery):
    """Ad-hoc policy question, outside the audit pipeline. Useful for testing
    the RAG layer directly. Tokens used are logged under agent='rag-query'."""
    if not payload.question.strip():
        raise HTTPException(status_code=400, detail="question cannot be empty")
    answer, chunks = answer_policy_question(payload.question, case_id=payload.case_id)
    return {"question": payload.question, "answer": answer, "retrieved_chunks": chunks}


@router.post("/evaluate")
async def evaluate(payload: RagEvalBatch):
    """
    Run a batch of policy questions through the RAG pipeline and score:
      - avg_relevance_score / top_relevance_score: cosine similarity of
        retrieved chunks vs the query (retrieval quality)
      - relevant_chunk_count: chunks above the relevance threshold
      - groundedness_score: how much of the generated answer is lexically
        supported by the retrieved chunks (hallucination proxy)
      - keyword_match_score: overlap with expected_answer, if supplied
    Each question + score is persisted to rag_eval and to the Prometheus
    histograms skeptic_rag_top_relevance_score / skeptic_rag_groundedness_score.
    """
    if not payload.questions:
        raise HTTPException(status_code=400, detail="questions list cannot be empty")
    return evaluate_rag_batch([q.model_dump() for q in payload.questions])


@router.post("/evaluate/single")
async def evaluate_single(item: RagEvalItem):
    return evaluate_rag(item.query, item.expected_answer)


@router.get("/evaluations")
async def get_evaluations(run_id: str | None = None, limit: int = 50):
    return list_rag_evals(run_id=run_id, limit=limit)
