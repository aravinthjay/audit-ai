"""app/api/v1/router.py"""
from fastapi import APIRouter
from app.api.v1.endpoints import intake, cases, review, reports, audit, rag, tokens

api_router = APIRouter(prefix="/api/v1")
api_router.include_router(intake.router)
api_router.include_router(cases.router)
api_router.include_router(review.router)
api_router.include_router(reports.router)
api_router.include_router(audit.router)
api_router.include_router(rag.router)
api_router.include_router(tokens.router)
