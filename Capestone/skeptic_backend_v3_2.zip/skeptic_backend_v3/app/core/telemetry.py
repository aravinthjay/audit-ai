"""app/core/telemetry.py
Central place for the two observability integrations:

1. LangSmith — every LLM call (challenger/defender/adjudicator/RAG) is wrapped
   with @traceable so a full trace tree shows up in the LangSmith project.
   This supplements (does not replace) the existing hash-chained audit_log —
   LangSmith run IDs are stored alongside each audit_log/token_usage row so a
   human auditor can jump from a DB row straight into the LangSmith trace UI.

2. Prometheus — request-level metrics via prometheus-fastapi-instrumentator,
   plus custom counters/histograms for tokens, LLM latency, RAG retrieval
   quality, and case routing outcomes. Exposed at GET /metrics.
"""
from __future__ import annotations
import os
from contextlib import contextmanager

from prometheus_client import Counter, Histogram

from app.core.config import get_settings

# ---------------------------------------------------------------------------
# LangSmith bootstrap — the SDK reads these env vars at import/call time.
# ---------------------------------------------------------------------------
_langsmith_ready = False


def init_langsmith() -> None:
    global _langsmith_ready
    settings = get_settings()
    if settings.langsmith_tracing and settings.langsmith_api_key:
        os.environ["LANGCHAIN_TRACING_V2"] = "true"
        os.environ["LANGCHAIN_API_KEY"] = settings.langsmith_api_key
        os.environ["LANGCHAIN_PROJECT"] = settings.langsmith_project
        os.environ["LANGCHAIN_ENDPOINT"] = settings.langsmith_endpoint
        _langsmith_ready = True
    else:
        os.environ["LANGCHAIN_TRACING_V2"] = "false"
        _langsmith_ready = False


def langsmith_enabled() -> bool:
    return _langsmith_ready


def get_current_run_id() -> str:
    """Best-effort: read the active LangSmith run id (if tracing is on) so it
    can be stamped onto audit_log / token_usage rows for cross-referencing."""
    if not _langsmith_ready:
        return ""
    try:
        from langsmith.run_helpers import get_current_run_tree
        rt = get_current_run_tree()
        return str(rt.id) if rt else ""
    except Exception:
        return ""


# ---------------------------------------------------------------------------
# Prometheus metrics
# ---------------------------------------------------------------------------
LLM_TOKENS_TOTAL = Counter(
    "skeptic_llm_tokens_total", "Total LLM tokens consumed",
    ["agent", "model", "token_type"],  # token_type: prompt | completion
)

LLM_CALL_LATENCY = Histogram(
    "skeptic_llm_call_latency_seconds", "Latency of individual LLM calls",
    ["agent", "model"],
)

LLM_COST_USD_TOTAL = Counter(
    "skeptic_llm_cost_usd_total", "Estimated cumulative LLM spend in USD",
    ["agent", "model"],
)

RAG_RETRIEVAL_LATENCY = Histogram(
    "skeptic_rag_retrieval_latency_seconds", "Latency of RAG chunk retrieval (excludes LLM call)",
)

RAG_RELEVANCE_SCORE = Histogram(
    "skeptic_rag_top_relevance_score", "Top cosine relevance score of RAG retrievals",
    buckets=(0, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.7, 1.0),
)

RAG_GROUNDEDNESS_SCORE = Histogram(
    "skeptic_rag_groundedness_score", "Fraction of RAG answer supported by retrieved chunks",
    buckets=(0, 0.1, 0.2, 0.3, 0.5, 0.7, 0.9, 1.0),
)

CASE_ROUTING_TOTAL = Counter(
    "skeptic_case_routing_total", "Cases routed by the confidence gate",
    ["routing"],  # auto_clear | review | manual
)

DEBATE_ROUNDS_TOTAL = Counter(
    "skeptic_debate_rounds_total", "Total debate rounds executed (incl. re-runs)",
)


@contextmanager
def time_llm_call(agent: str, model: str):
    """Context manager: records LLM_CALL_LATENCY automatically."""
    with LLM_CALL_LATENCY.labels(agent=agent, model=model).time():
        yield


def record_token_usage(agent: str, model: str, prompt_tokens: int,
                       completion_tokens: int, cost_usd: float) -> None:
    LLM_TOKENS_TOTAL.labels(agent=agent, model=model, token_type="prompt").inc(prompt_tokens)
    LLM_TOKENS_TOTAL.labels(agent=agent, model=model, token_type="completion").inc(completion_tokens)
    LLM_COST_USD_TOTAL.labels(agent=agent, model=model).inc(cost_usd)
