"""app/agents/orchestrator.py — LangGraph orchestration for the audit pipeline.

This is the actual workflow engine for one case run. Previously this was a
hand-written Python while-loop inside run_pipeline_for_case(); it's now a
genuine StateGraph with three nodes and one conditional (cyclic) edge:

    START -> collect_evidence -> debate_round --(low confidence, attempts left)--> debate_round (loop)
                                       |
                                       +--(confident enough, OR attempts exhausted)--> confidence_gate -> END

Every node still calls the exact same LLM/evidence/audit/metrics code as
before (run_debate_round, collect_evidence, _generate_report in pipeline.py)
— LangGraph only owns the *sequencing and branching*, not the business logic
itself, so nothing about evidence collection, the debate prompts, or the
routing rules changed by introducing this.
"""
from __future__ import annotations
import json
from datetime import datetime, timezone

from langgraph.graph import StateGraph, START, END
from typing_extensions import TypedDict

from app.core.config import get_settings
from app.core.telemetry import CASE_ROUTING_TOTAL
from app.db.database import get_db
from app.services.audit_log_service import append_event
from app.services.evidence_service import collect_evidence


class PipelineState(TypedDict, total=False):
    case_id: str
    transaction: dict
    flags: list
    evidence: dict
    debate_history: list
    attempt: int
    max_attempts: int
    confidence: float
    risk: str
    adjudication: dict
    routing: str
    escalation_reason: str


# ---------------------------------------------------------------------------
# Node 1 — Phase 1: evidence collection
# ---------------------------------------------------------------------------
async def node_collect_evidence(state: PipelineState) -> dict:
    case_id = state["case_id"]
    with get_db() as conn:
        conn.execute("UPDATE cases SET status=? WHERE id=?", ("collecting_evidence", case_id))
    append_event("system", "pipeline", "Phase 1 — evidence collection started", {}, case_id=case_id)

    evidence = await collect_evidence(state["transaction"], state["flags"], case_id=case_id)

    with get_db() as conn:
        conn.execute("UPDATE cases SET evidence=?, status=? WHERE id=?",
                    (json.dumps(evidence), "agent_debate", case_id))
    append_event("agent", "evidence-agent", "Evidence collected",
                 {"policy_confidence": evidence["policy_analysis"]["confidence"]}, case_id=case_id)
    return {"evidence": evidence}


# ---------------------------------------------------------------------------
# Node 2 — Phase 2: one debate round (this node is the loop body)
# ---------------------------------------------------------------------------
async def node_debate_round(state: PipelineState) -> dict:
    # Imported here (not at module load) to avoid a circular import with pipeline.py
    from app.agents.pipeline import run_debate_round

    settings = get_settings()
    case_id = state["case_id"]
    debate_history = state.get("debate_history", [])
    attempt = state.get("attempt", 1)

    prior_challenger_args = [r["challenger"]["argument"] for r in debate_history]
    prior_defender_args = [r["defender"]["argument"] for r in debate_history]

    round_result = await run_debate_round(
        case_id, state["transaction"], state["evidence"], attempt,
        prior_challenger_args=prior_challenger_args or None,
        prior_defender_args=prior_defender_args or None,
    )
    debate_history = debate_history + [round_result]
    confidence = round_result["adjudication"]["confidence"]

    if confidence < settings.confidence_review_low and attempt < state["max_attempts"]:
        append_event("system", "pipeline",
                     f"Confidence {confidence} < {settings.confidence_review_low} — re-running debate",
                     {"attempt": attempt, "confidence": confidence}, case_id=case_id)

    with get_db() as conn:
        conn.execute(
            """UPDATE cases SET challenger_view=?, defender_view=?, adjudication=?,
               confidence=?, risk=?, disposition=?, attempt_count=?, debate_history=?
               WHERE id=?""",
            (json.dumps(round_result["challenger"]), json.dumps(round_result["defender"]),
             json.dumps(round_result["adjudication"]), confidence, round_result["adjudication"]["risk"],
             round_result["adjudication"]["disposition"], len(debate_history),
             json.dumps(debate_history), case_id),
        )

    return {
        "debate_history": debate_history,
        "attempt": attempt + 1,
        "confidence": confidence,
        "risk": round_result["adjudication"]["risk"],
        "adjudication": round_result["adjudication"],
    }


def _route_after_debate(state: PipelineState) -> str:
    """The graph's only conditional edge: keep debating, or move to the gate.
    Mirrors the original while-loop's exit conditions exactly:
      - confidence is high enough to stop early, OR
      - the hard attempt cap (max_debate_attempts, default 3) has been reached
    """
    settings = get_settings()
    total_attempts = len(state["debate_history"])
    if state["confidence"] >= settings.confidence_review_low:
        return "gate"
    if total_attempts >= state["max_attempts"]:
        return "gate"
    return "debate_round"


# ---------------------------------------------------------------------------
# Node 3 — Phase 3: confidence gate (3 independent exit paths)
# ---------------------------------------------------------------------------
async def node_confidence_gate(state: PipelineState) -> dict:
    from app.agents.pipeline import _generate_report  # avoid circular import

    settings = get_settings()
    case_id = state["case_id"]
    confidence = state["confidence"]
    risk = state["risk"]
    adjudication = state["adjudication"]
    total_attempts = len(state["debate_history"])
    max_attempts = state["max_attempts"]
    now = datetime.now(timezone.utc).isoformat()

    # Hitting the attempt cap at all forces manual review, REGARDLESS of the
    # final confidence/risk — the agents never converged within the allowed
    # re-runs, so a human has to look at it no matter how attempt N landed.
    rerun_exhausted = total_attempts >= max_attempts

    escalation_reason = ""
    if rerun_exhausted:
        routing = "manual"
        escalation_reason = "debate_attempts_exhausted"
        append_event("system", "pipeline", "Forced escalation — used all debate attempts without early resolution",
                     {"attempts": total_attempts, "max_attempts": max_attempts, "final_confidence": confidence,
                      "escalation_reason": escalation_reason}, case_id=case_id)

    elif confidence >= settings.confidence_auto_clear and risk in ("low", "cleared"):
        routing = "auto_clear"

    elif confidence >= settings.confidence_review_low:
        if risk in ("high", "critical"):
            routing = "manual"
            escalation_reason = "high_risk_despite_confidence"
            append_event("system", "pipeline", "Forced escalation — risk too high for auto-routing",
                         {"risk": risk, "confidence": confidence,
                          "escalation_reason": escalation_reason}, case_id=case_id)
        else:
            routing = "review"  # goes straight to report — no human interrupt

    else:
        routing = "manual"  # risk-driven manual (e.g. critical risk despite passable confidence)

    with get_db() as conn:
        conn.execute(
            "UPDATE cases SET routing=?, escalation_reason=?, status=?, updated_at=? WHERE id=?",
            (routing, escalation_reason,
             "pending_human_review" if routing == "manual" else "report_ready",
             now, case_id),
        )

    append_event("system", "pipeline", f"Confidence gate routed case to: {routing}",
                 {"routing": routing, "confidence": confidence, "risk": risk,
                  "escalation_reason": escalation_reason}, case_id=case_id)
    CASE_ROUTING_TOTAL.labels(routing=routing).inc()

    if routing in ("auto_clear", "review"):
        await _generate_report(case_id, routing, risk, confidence, adjudication, human_reviewed=False)

    return {"routing": routing, "escalation_reason": escalation_reason}


# ---------------------------------------------------------------------------
# Graph assembly — compiled once, reused across requests
# ---------------------------------------------------------------------------
def build_pipeline_graph():
    graph = StateGraph(PipelineState)
    graph.add_node("collect_evidence", node_collect_evidence)
    graph.add_node("debate_round", node_debate_round)
    graph.add_node("confidence_gate", node_confidence_gate)

    graph.add_edge(START, "collect_evidence")
    graph.add_edge("collect_evidence", "debate_round")
    graph.add_conditional_edges("debate_round", _route_after_debate,
                                {"debate_round": "debate_round", "gate": "confidence_gate"})
    graph.add_edge("confidence_gate", END)
    return graph.compile()


_compiled_graph = None


def get_pipeline_graph():
    global _compiled_graph
    if _compiled_graph is None:
        _compiled_graph = build_pipeline_graph()
    return _compiled_graph
