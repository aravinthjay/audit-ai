"""app/services/vector_store.py — Pinecone-backed chunk store for RAG.

Embeddings: there is no free, no-signup embedding API or local model download
available in this environment (real embedding models need either a paid API
key or downloading weights from a host outside this app's network allowlist).
So this uses the classic "hashing trick" / feature hashing: every chunk is
turned into a fixed-dimension vector by hashing each word into a bucket and
summing signed counts, then L2-normalizing. It's free, deterministic, and
needs no model download — conceptually similar to TF-IDF, just hashed into a
fixed dimension so it's compatible with Pinecone's vector index instead of a
variable-length sparse vector.

Like every other optional 3rd-party integration in this app (FX check,
GST/PNR verification), Pinecone is OPTIONAL: if PINECONE_API_KEY is unset or
the service is unreachable, `available` is False and rag_service.py falls
back to the original in-memory TF-IDF retrieval automatically. The PDF on
disk is always the real source of truth; Pinecone is just an index over it.
"""
from __future__ import annotations
import hashlib
import math
import re

from app.core.config import get_settings

_TOKEN_RE = re.compile(r"[a-z0-9]+")


def _tokenize(text: str) -> list[str]:
    return _TOKEN_RE.findall(text.lower())


def embed_text(text: str, dim: int) -> list[float]:
    """Free, local, deterministic fixed-dimension embedding via feature hashing."""
    vec = [0.0] * dim
    for token in _tokenize(text):
        digest = hashlib.sha256(token.encode()).hexdigest()
        h = int(digest, 16)
        idx = h % dim
        sign = 1.0 if (h // dim) % 2 == 0 else -1.0
        vec[idx] += sign
    norm = math.sqrt(sum(v * v for v in vec)) or 1.0
    return [v / norm for v in vec]


class VectorStore:
    """Thin wrapper around a Pinecone index. Every method degrades to a clean
    no-op / None return if Pinecone isn't configured or errors out — callers
    (rag_service.py) treat that as "use the local fallback instead."
    """

    def __init__(self):
        self.settings = get_settings()
        self._pc = None
        self._index = None
        self._available = False
        self._init_error: str | None = None

        if not self.settings.pinecone_api_key:
            self._init_error = "PINECONE_API_KEY not set — using local TF-IDF fallback."
            return

        try:
            from pinecone import Pinecone, ServerlessSpec

            self._pc = Pinecone(api_key=self.settings.pinecone_api_key)
            existing = {i["name"] for i in self._pc.list_indexes()}
            if self.settings.pinecone_index_name not in existing:
                self._pc.create_index(
                    name=self.settings.pinecone_index_name,
                    dimension=self.settings.embedding_dim,
                    metric="cosine",
                    spec=ServerlessSpec(cloud=self.settings.pinecone_cloud,
                                       region=self.settings.pinecone_region),
                )
            self._index = self._pc.Index(self.settings.pinecone_index_name)
            self._available = True
        except Exception as e:
            self._init_error = f"Pinecone init failed ({e}) — using local TF-IDF fallback."
            self._available = False

    @property
    def available(self) -> bool:
        return self._available

    def upsert_chunks(self, chunks: list[str]) -> bool:
        """Embeds and upserts every chunk. Returns False (and disables itself
        for this process) if anything goes wrong."""
        if not self._available:
            return False
        try:
            vectors = [
                (str(i), embed_text(chunk, self.settings.embedding_dim), {"text": chunk})
                for i, chunk in enumerate(chunks)
            ]
            self._index.upsert(vectors=vectors)
            return True
        except Exception:
            self._available = False
            return False

    def query(self, query_text: str, top_k: int) -> list[tuple[str, float]] | None:
        """Returns [(chunk_text, score), ...] or None if Pinecone is unavailable
        (caller should fall back to local TF-IDF retrieval in that case)."""
        if not self._available:
            return None
        try:
            qvec = embed_text(query_text, self.settings.embedding_dim)
            res = self._index.query(vector=qvec, top_k=top_k, include_metadata=True)
            return [(m["metadata"]["text"], float(m["score"])) for m in res.get("matches", [])]
        except Exception:
            self._available = False
            return None


_store: VectorStore | None = None


def get_vector_store() -> VectorStore:
    global _store
    if _store is None:
        _store = VectorStore()
    return _store
