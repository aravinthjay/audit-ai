"""app/services/evidence_service.py — Phase 1: evidence collection.

Now four sources feed the debate, not two:
  1. RAG policy lookup            (rag_service.answer_policy_question)
  2. FX check                     (only when flagged fx-outlier)
  3. Transaction classification   (classifier_service.classify_transaction)
  4. Third-party validation       (validation_service.validate_transaction)
     -> dispatched based on (3)'s category: PNR check for flight/train,
        GSTIN check for hotel/restaurant, amount-vs-benchmark for all of them.
"""
from __future__ import annotations
import asyncio
import httpx

from app.core.config import get_settings
from app.services.rag_service import answer_policy_question
from app.services.classifier_service import classify_transaction
from app.services.validation_service import validate_transaction

_TIMEOUT = 8.0


async def check_fx(currency: str, claimed_rate: float) -> dict | None:
    if currency == "USD":
        return None
    settings = get_settings()
    try:
        async with httpx.AsyncClient(timeout=_TIMEOUT) as client:
            r = await client.get(f"{settings.frankfurter_base_url}/latest",
                                 params={"from": currency, "to": "USD"})
            r.raise_for_status()
            live_rate = r.json()["rates"]["USD"]
            deviation = abs(claimed_rate - live_rate) / max(live_rate, 0.0001) * 100
            return {"live_rate": round(live_rate, 6), "claimed_rate": claimed_rate,
                    "outlier": deviation > 5.0, "deviation_pct": round(deviation, 2)}
    except Exception:
        return {"live_rate": None, "claimed_rate": claimed_rate, "outlier": None,
                "deviation_pct": None, "note": "live_lookup_unavailable"}


async def collect_evidence(transaction: dict, flags: list[str], case_id: str | None = None) -> dict:
    """
    Phase 1 — evidence agent. Combines RAG policy lookup + FX check +
    transaction classification + third-party (PNR/GSTIN/benchmark) validation.
    Returns evidence{ } consumed by Phase 2 debate.
    """
    vendor = transaction["vendor"]
    amount_usd = transaction["amount_usd"]
    currency = transaction["currency"]
    fx_rate = transaction["fx_rate"]

    policy_question = (
        f"What policy applies to a {amount_usd:.0f} USD transaction "
        f"with vendor '{vendor}' flagged for {', '.join(flags)}?"
    )
    policy_answer, policy_chunks = await asyncio.to_thread(
        answer_policy_question, policy_question, case_id=case_id, agent_label="evidence-rag"
    )

    fx_result = await check_fx(currency, fx_rate) if "fx-outlier" in flags else None

    # --- Phase 1a: classify, then validate against the right 3rd-party check ---
    classification = await asyncio.to_thread(classify_transaction, transaction, case_id=case_id)
    validation = await validate_transaction(classification["category"], transaction)

    evidence = {
        "transaction_summary": {
            "vendor": vendor, "amount_usd": amount_usd,
            "currency": currency, "flags": flags,
        },
        "policy_analysis": {
            "answer": policy_answer,
            "citations": [c[:120] + "..." for c in policy_chunks[:2]],
            "confidence": 0.82,
            "quality": "adequate",
        },
        "fx_check": fx_result,
        "classification": classification,
        "third_party_validation": validation,
        "materiality_flag": "materiality" in flags,
        "unknown_vendor_flag": "unknown-vendor" in flags,
        "sod_flag": "segregation-of-duties" in flags,
    }
    return evidence
