"""app/services/rag_service.py — TF-IDF RAG over company_policy.pdf.

Instrumented with:
  - LangSmith @traceable spans on retrieve() and answer_policy_question()
    so every retrieval + generation shows up as a trace.
  - Token usage logging (Groq returns prompt/completion/total tokens on
    every response) persisted to the token_usage table + Prometheus.
  - evaluate_rag() / evaluate_rag_batch() for the standalone RAG eval API:
    computes retrieval relevance (cosine score vs the TF-IDF index),
    groundedness (lexical overlap between the generated answer and the
    retrieved chunks), and — if a reference answer is supplied — a simple
    keyword-overlap accuracy score.
"""
from __future__ import annotations
import math
import re
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

from groq import Groq
from langsmith import traceable

from app.core.config import get_settings
from app.core.telemetry import RAG_RETRIEVAL_LATENCY, RAG_RELEVANCE_SCORE, RAG_GROUNDEDNESS_SCORE
from app.db.database import get_db
from app.services.token_usage_service import log_token_usage
from app.services.vector_store import get_vector_store

POLICY_PDF_PATH = Path(__file__).parent.parent / "knowledge" / "company_policy.pdf"
CHUNK_SIZE, OVERLAP, TOP_K = 400, 60, 4
RAG_MODEL = "llama-3.1-8b-instant"

_chunks: list[str] = []
_tfidf_matrix: list[dict] = []
_idf: dict[str, float] = {}
_loaded = False

_FALLBACK_POLICY = """
SKEPTIC ENGINE CORP — TRAVEL & ENTERTAINMENT EXPENSE POLICY v3.1
SECTION 2 — BILL REQUIREMENTS: PNR mandatory for flight/train/bus. GSTIN required on hotel and restaurant bills above INR 1,000.
SECTION 2.2 — PNR: Flight PNR 6-char alphanumeric IATA. Train PNR 10-digit IRCTC.
SECTION 2.3 — GST RATES: Hotel < INR 7,500/night: 12%. Hotel > INR 7,500/night: 18%. Restaurant: 5%.
SECTION 3.1 — HOTEL ENTITLEMENT: L1-L2: INR 3,500/night. L3-L4: INR 5,000/night. L5-L6: INR 8,000/night. L7-L8: INR 12,000/night.
SECTION 4 — PRE-APPROVAL: > INR 25,000: Senior Manager. > INR 1,00,000: Director + Finance.
SECTION 5 — NON-REIMBURSABLE: Alcohol, duplicate claims, bills > 30 days old.
SECTION 8 — FRAUD: Forged bills, ghost expenses, duplicate submissions = termination.
"""


def _extract_pdf_text(path: Path) -> str:
    try:
        from pypdf import PdfReader
        reader = PdfReader(str(path))
        return "\n\n".join(p.extract_text() or "" for p in reader.pages)
    except Exception:
        return _FALLBACK_POLICY


def _tokenise(text: str) -> list[str]:
    return re.findall(r"[a-z0-9]+", text.lower())


def _chunk_text(text: str) -> list[str]:
    words = text.split()
    chunks, i = [], 0
    while i < len(words):
        c = " ".join(words[i:i + CHUNK_SIZE])
        if c.strip():
            chunks.append(c)
        i += CHUNK_SIZE - OVERLAP
    return chunks


def _build_tfidf(chunks: list[str]):
    n = len(chunks)
    tf_docs, df = [], {}
    for chunk in chunks:
        tokens = _tokenise(chunk)
        total = max(len(tokens), 1)
        tf = {}
        for t in tokens:
            tf[t] = tf.get(t, 0) + 1
        for t in tf:
            tf[t] /= total
            df[t] = df.get(t, 0) + 1
        tf_docs.append(tf)
    idf = {t: math.log((n + 1) / (c + 1)) + 1 for t, c in df.items()}
    return [{t: tf[t] * idf[t] for t in tf} for tf in tf_docs], idf


def _cosine(a: dict, b: dict) -> float:
    common = set(a) & set(b)
    if not common:
        return 0.0
    dot = sum(a[t] * b[t] for t in common)
    na = math.sqrt(sum(v * v for v in a.values()))
    nb = math.sqrt(sum(v * v for v in b.values()))
    return dot / (na * nb) if na and nb else 0.0


def _query_vec(query: str) -> dict:
    tokens = _tokenise(query)
    tf, total = {}, max(len(tokens), 1)
    for t in tokens:
        tf[t] = tf.get(t, 0) + 1
    for t in tf:
        tf[t] /= total
    return {t: tf[t] * _idf.get(t, 1.0) for t in tf}


def _load_policy() -> None:
    global _chunks, _tfidf_matrix, _idf, _loaded
    if _loaded:
        return
    text = _extract_pdf_text(POLICY_PDF_PATH) if POLICY_PDF_PATH.exists() else _FALLBACK_POLICY
    _chunks = _chunk_text(text)
    _tfidf_matrix, _idf = _build_tfidf(_chunks)
    _loaded = True

    # Mirror the same chunks into Pinecone, if configured. This is additive —
    # the in-memory TF-IDF index above is built either way, so retrieval still
    # works perfectly even if this upsert fails or Pinecone isn't configured.
    store = get_vector_store()
    if store.available:
        store.upsert_chunks(_chunks)


@traceable(name="rag_retrieve", run_type="retriever")
def retrieve_scored(query: str, top_k: int = TOP_K) -> list[tuple[str, float]]:
    """Like retrieve() but also returns the cosine score per chunk — needed for eval.
    Tries Pinecone first; transparently falls back to the in-memory TF-IDF scan
    if Pinecone isn't configured or errors out — chunk content is identical
    either way since both are populated from the same _load_policy() call."""
    _load_policy()
    start = time.perf_counter()

    store = get_vector_store()
    if store.available:
        pinecone_result = store.query(query, top_k)
        if pinecone_result is not None:
            RAG_RETRIEVAL_LATENCY.observe(time.perf_counter() - start)
            return pinecone_result

    qv = _query_vec(query)
    scored = sorted(
        [(i, _cosine(qv, dv)) for i, dv in enumerate(_tfidf_matrix)],
        key=lambda x: x[1], reverse=True,
    )
    RAG_RETRIEVAL_LATENCY.observe(time.perf_counter() - start)
    return [(_chunks[i], s) for i, s in scored[:top_k]]


def retrieve(query: str, top_k: int = TOP_K) -> list[str]:
    return [c for c, s in retrieve_scored(query, top_k) if s > 0]


@traceable(name="rag_answer_policy_question", run_type="chain")
def answer_policy_question(question: str, case_id: str | None = None,
                           agent_label: str = "rag-query") -> tuple[str, list[str]]:
    _load_policy()
    chunks = retrieve(question)
    context = "\n\n---\n".join(chunks) if chunks else _FALLBACK_POLICY[:2000]
    settings = get_settings()
    client = Groq(api_key=settings.groq_api_key)

    start = time.perf_counter()
    resp = client.chat.completions.create(
        model=RAG_MODEL, max_tokens=400, temperature=0.1,
        messages=[
            {"role": "system", "content": "You are an audit compliance officer. Answer strictly from the provided policy. Cite section numbers."},
            {"role": "user", "content": f"Policy excerpts:\n{context}\n\nQuestion: {question}"},
        ],
    )
    latency_ms = (time.perf_counter() - start) * 1000

    usage = getattr(resp, "usage", None)
    prompt_tokens = getattr(usage, "prompt_tokens", 0) or 0
    completion_tokens = getattr(usage, "completion_tokens", 0) or 0
    log_token_usage(agent_label, RAG_MODEL, prompt_tokens, completion_tokens, latency_ms, case_id=case_id)

    return resp.choices[0].message.content.strip(), chunks


# ---------------------------------------------------------------------------
# RAG evaluation
# ---------------------------------------------------------------------------
def _groundedness(answer: str, chunks: list[str]) -> float:
    """Fraction of the answer's distinct content words that also appear in the
    retrieved chunks — a cheap, dependency-free proxy for 'is the answer
    actually supported by the retrieved context'."""
    answer_tokens = set(_tokenise(answer)) - _STOPWORDS
    if not answer_tokens:
        return 0.0
    context_tokens = set()
    for c in chunks:
        context_tokens |= set(_tokenise(c))
    if not context_tokens:
        return 0.0
    supported = answer_tokens & context_tokens
    return round(len(supported) / len(answer_tokens), 4)


def _keyword_match(answer: str, expected: str) -> float:
    if not expected:
        return 0.0
    exp_tokens = set(_tokenise(expected)) - _STOPWORDS
    if not exp_tokens:
        return 0.0
    ans_tokens = set(_tokenise(answer)) - _STOPWORDS
    return round(len(exp_tokens & ans_tokens) / len(exp_tokens), 4)


_STOPWORDS = {
    "the", "a", "an", "is", "are", "of", "to", "and", "for", "on", "in",
    "this", "that", "be", "as", "or", "it", "with", "at", "by", "from",
    "policy", "section", "must", "will", "should",
}


@traceable(name="rag_evaluate_one", run_type="chain")
def evaluate_rag(query: str, expected_answer: str = "", run_id: str = "",
                 case_id: str | None = None) -> dict:
    settings = get_settings()
    start = time.perf_counter()

    scored_chunks = retrieve_scored(query)
    answer, _ = answer_policy_question(query, case_id=case_id, agent_label="rag-eval")

    latency_ms = (time.perf_counter() - start) * 1000
    scores = [s for _, s in scored_chunks]
    avg_score = round(sum(scores) / len(scores), 4) if scores else 0.0
    top_score = round(max(scores), 4) if scores else 0.0
    relevant_count = sum(1 for s in scores if s >= settings.rag_eval_relevance_threshold)
    groundedness = _groundedness(answer, [c for c, _ in scored_chunks])
    keyword_score = _keyword_match(answer, expected_answer)

    RAG_RELEVANCE_SCORE.observe(top_score)
    RAG_GROUNDEDNESS_SCORE.observe(groundedness)

    eval_id = f"EVAL-{uuid.uuid4().hex[:8].upper()}"
    now = datetime.now(timezone.utc).isoformat()
    record = {
        "id": eval_id, "run_id": run_id or eval_id, "query": query,
        "expected_answer": expected_answer, "answer": answer,
        "retrieved_chunks": [c[:300] for c, _ in scored_chunks],
        "chunk_scores": scores,
        "avg_relevance_score": avg_score, "top_relevance_score": top_score,
        "relevant_chunk_count": relevant_count,
        "groundedness_score": groundedness, "keyword_match_score": keyword_score,
        "latency_ms": round(latency_ms, 2), "created_at": now,
    }

    import json
    with get_db() as conn:
        conn.execute(
            """INSERT INTO rag_eval
               (id, run_id, query, expected_answer, answer, retrieved_chunks,
                chunk_scores, avg_relevance_score, top_relevance_score,
                relevant_chunk_count, groundedness_score, keyword_match_score,
                latency_ms, created_at)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (eval_id, record["run_id"], query, expected_answer, answer,
             json.dumps(record["retrieved_chunks"]), json.dumps(scores),
             avg_score, top_score, relevant_count, groundedness, keyword_score,
             record["latency_ms"], now),
        )
    return record


def evaluate_rag_batch(questions: list[dict]) -> dict:
    """questions: [{"query": str, "expected_answer": str (optional)}, ...]"""
    run_id = f"RUN-{uuid.uuid4().hex[:8].upper()}"
    results = [
        evaluate_rag(q["query"], q.get("expected_answer", ""), run_id=run_id)
        for q in questions
    ]
    n = len(results) or 1
    aggregate = {
        "run_id": run_id,
        "question_count": len(results),
        "avg_relevance_score": round(sum(r["avg_relevance_score"] for r in results) / n, 4),
        "avg_top_relevance_score": round(sum(r["top_relevance_score"] for r in results) / n, 4),
        "avg_groundedness_score": round(sum(r["groundedness_score"] for r in results) / n, 4),
        "avg_keyword_match_score": round(
            sum(r["keyword_match_score"] for r in results if r["expected_answer"]) /
            max(1, sum(1 for r in results if r["expected_answer"])), 4
        ) if any(r["expected_answer"] for r in results) else None,
        "avg_latency_ms": round(sum(r["latency_ms"] for r in results) / n, 2),
    }
    return {"run_id": run_id, "aggregate": aggregate, "results": results}


def list_rag_evals(run_id: str | None = None, limit: int = 50) -> list[dict]:
    import json
    q = "SELECT * FROM rag_eval WHERE 1=1"
    params: list = []
    if run_id:
        q += " AND run_id=?"; params.append(run_id)
    q += " ORDER BY created_at DESC LIMIT ?"; params.append(limit)
    with get_db() as conn:
        rows = conn.execute(q, params).fetchall()
    out = []
    for r in rows:
        d = dict(r)
        d["retrieved_chunks"] = json.loads(d.get("retrieved_chunks") or "[]")
        d["chunk_scores"] = json.loads(d.get("chunk_scores") or "[]")
        out.append(d)
    return out
