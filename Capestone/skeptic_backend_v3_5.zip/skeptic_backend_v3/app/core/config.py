"""app/core/config.py"""
from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    cors_origins: str = "http://localhost:3000"
    groq_api_key: str = ""

    frankfurter_base_url: str = "https://api.frankfurter.app"

    # Phase 0 — intake
    materiality_threshold: float = 25_000.0

    # Phase 3 — confidence gate
    confidence_auto_clear: float = 0.90
    confidence_review_low: float = 0.70
    debate_round_cap: int = 2   # max re-runs BEFORE forced escalation (3 total attempts)

    # --- Observability: LangSmith (tracing / audit of every LLM + RAG call) ---
    langsmith_tracing: bool = False
    langsmith_api_key: str = ""
    langsmith_project: str = "skeptic-engine"
    langsmith_endpoint: str = "https://api.smith.langchain.com"

    # --- Observability: Prometheus ---
    prometheus_enabled: bool = True

    # --- Token usage cost estimation (USD per 1K tokens, Groq llama-3.1-8b-instant) ---
    cost_per_1k_prompt_tokens: float = 0.00005
    cost_per_1k_completion_tokens: float = 0.00008

    # --- RAG evaluation ---
    rag_eval_relevance_threshold: float = 0.05  # min cosine score to count as "relevant"

    # --- Phase 1b — Transaction classification + 3rd-party validation ---
    validation_deviation_threshold_pct: float = 20.0  # claimed amount vs benchmark/live rate
    gst_verification_api_url: str = ""        # optional live GSTIN verification provider
    pnr_verification_api_url: str = ""        # optional live PNR verification provider (flight/train)
    travel_benchmark_api_url: str = ""        # optional live fare/rate benchmark provider

    # --- Phase 2 — Debate re-run cap ---
    # Total debate attempts allowed = debate_round_cap + 1 (e.g. cap=2 -> 3 attempts).
    # Once that many attempts are used WITHOUT an early confident exit, the case is
    # forced to manual review regardless of the final confidence score.
    max_debate_attempts: int = 3

    # --- RAG vector store: Pinecone ---
    # Optional — if PINECONE_API_KEY is unset, the app falls back to the original
    # in-memory TF-IDF retrieval automatically. No data is lost either way; the
    # source of truth is always the policy PDF, Pinecone is just an index over it.
    pinecone_api_key: str = ""
    pinecone_index_name: str = "skeptic-policy-chunks"
    pinecone_cloud: str = "aws"
    pinecone_region: str = "us-east-1"
    # Fixed embedding dimension for the free, local, no-model-download hashing
    # embedding used to populate Pinecone (see app/services/vector_store.py).
    embedding_dim: int = 512

    @property
    def cors_origins_list(self) -> list[str]:
        return [o.strip() for o in self.cors_origins.split(",")]


@lru_cache
def get_settings() -> Settings:
    return Settings()
