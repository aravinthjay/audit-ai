import { useEffect, useState } from "react";
import { NavLink, Route, Routes, Navigate } from "react-router-dom";
import { getHealth } from "./api";

import Intake from "./pages/Intake";
import Cases from "./pages/Cases";
import CaseDetail from "./pages/CaseDetail";
import Review from "./pages/Review";
import Reports from "./pages/Reports";
import AuditLog from "./pages/AuditLog";
import RagQuery from "./pages/RagQuery";
import RagEvaluate from "./pages/RagEvaluate";
import Tokens from "./pages/Tokens";
import Metrics from "./pages/Metrics";

const NAV = [
  { group: "Pipeline", items: [
    { to: "/intake", label: "Phase 0 — Intake" },
    { to: "/cases", label: "Phase 1–3 — Cases" },
    { to: "/review", label: "Human Review" },
    { to: "/reports", label: "Reports" },
  ]},
  { group: "Trust & Audit", items: [
    { to: "/audit", label: "Audit Log" },
  ]},
  { group: "RAG", items: [
    { to: "/rag/query", label: "Policy Query" },
    { to: "/rag/evaluate", label: "RAG Evaluation" },
  ]},
  { group: "Observability", items: [
    { to: "/tokens", label: "Token Usage" },
    { to: "/metrics", label: "Metrics & Tracing" },
  ]},
];

function ConnStatus() {
  const [state, setState] = useState("checking"); // checking | up | down

  useEffect(() => {
    let mounted = true;
    const check = () =>
      getHealth()
        .then(() => mounted && setState("up"))
        .catch(() => mounted && setState("down"));
    check();
    const id = setInterval(check, 15000);
    return () => { mounted = false; clearInterval(id); };
  }, []);

  const color = state === "up" ? "var(--good)" : state === "down" ? "var(--bad)" : "var(--muted-2)";
  const label = state === "up" ? "backend connected" : state === "down" ? "backend unreachable" : "checking…";
  return (
    <div className="conn-status">
      <span className="pulse" style={{ background: color }} />
      {label}
    </div>
  );
}

export default function App() {
  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="mark">SKEPTIC ENGINE</div>
          <h1>Audit Console</h1>
          <div className="sub">v3.1.0 · 3-path pipeline</div>
        </div>

        {NAV.map((g) => (
          <div className="nav-group" key={g.group}>
            <div className="nav-label">{g.group}</div>
            {g.items.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                className={({ isActive }) => "nav-link" + (isActive ? " active" : "")}
              >
                <span className="dot" />
                {item.label}
              </NavLink>
            ))}
          </div>
        ))}

        <ConnStatus />
      </aside>

      <main className="main">
        <Routes>
          <Route path="/" element={<Navigate to="/intake" replace />} />
          <Route path="/intake" element={<Intake />} />
          <Route path="/cases" element={<Cases />} />
          <Route path="/cases/:caseId" element={<CaseDetail />} />
          <Route path="/review" element={<Review />} />
          <Route path="/reports" element={<Reports />} />
          <Route path="/audit" element={<AuditLog />} />
          <Route path="/rag/query" element={<RagQuery />} />
          <Route path="/rag/evaluate" element={<RagEvaluate />} />
          <Route path="/tokens" element={<Tokens />} />
          <Route path="/metrics" element={<Metrics />} />
          <Route path="*" element={<Navigate to="/intake" replace />} />
        </Routes>
      </main>
    </div>
  );
}
