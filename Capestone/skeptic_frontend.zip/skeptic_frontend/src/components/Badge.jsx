export default function Badge({ value }) {
  if (value === undefined || value === null || value === "") return <span className="mono" style={{ color: "var(--muted-2)" }}>—</span>;
  const cls = String(value).toLowerCase().replace(/\s+/g, "_");
  return <span className={`badge b-${cls}`}>{String(value)}</span>;
}
