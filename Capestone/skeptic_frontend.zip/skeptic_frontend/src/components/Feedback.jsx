export function Loader({ label = "Loading…" }) {
  return (
    <div className="row" style={{ color: "var(--muted)", fontSize: 13, padding: "16px 0" }}>
      <span className="spinner" /> {label}
    </div>
  );
}

export function ErrorBox({ message }) {
  if (!message) return null;
  return <div className="error-box">⚠ {message}</div>;
}

export function SuccessBox({ message }) {
  if (!message) return null;
  return <div className="success-box">✓ {message}</div>;
}

export function Empty({ children = "Nothing here yet." }) {
  return <div className="empty">{children}</div>;
}
