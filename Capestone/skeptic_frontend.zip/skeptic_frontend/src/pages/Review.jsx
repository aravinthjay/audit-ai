import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { getReviewQueue, decideReview, getReviewHistory } from "../api";
import { Loader, ErrorBox, SuccessBox, Empty } from "../components/Feedback";
import Badge from "../components/Badge";

function DecisionForm({ caseRow, onDone }) {
  const [actor, setActor] = useState("");
  const [action, setAction] = useState("approved");
  const [comment, setComment] = useState("");
  const [signature, setSignature] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  const submit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    setError("");
    try {
      await decideReview(caseRow.id, { actor, action, comment, signature });
      onDone();
    } catch (e) {
      setError(e.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <form onSubmit={submit} style={{ marginTop: 10, paddingTop: 10, borderTop: "1px solid var(--border)" }}>
      <ErrorBox message={error} />
      <div className="row" style={{ marginBottom: 8 }}>
        <input placeholder="actor (your username)" value={actor} onChange={(e) => setActor(e.target.value)} required style={{ flex: 1 }} />
        <select value={action} onChange={(e) => setAction(e.target.value)}>
          <option value="approved">approved</option>
          <option value="rejected">rejected</option>
          <option value="requested_evidence">requested_evidence</option>
        </select>
      </div>
      <div className="row" style={{ marginBottom: 8 }}>
        <input placeholder="comment" value={comment} onChange={(e) => setComment(e.target.value)} style={{ flex: 1 }} />
        <input placeholder="signature" value={signature} onChange={(e) => setSignature(e.target.value)} style={{ flex: 1 }} />
      </div>
      <p style={{ fontSize: 11, color: "var(--muted-2)", margin: "0 0 8px" }}>
        Segregation of duties is enforced server-side: actor cannot be the same person who posted ({caseRow.posted_by}).
      </p>
      <button className="btn btn-primary" type="submit" disabled={submitting}>
        {submitting ? <span className="spinner" /> : "Submit decision"}
      </button>
    </form>
  );
}

export default function Review() {
  const [queue, setQueue] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [openId, setOpenId] = useState(null);
  const [history, setHistory] = useState({});

  const fetchQueue = () => {
    setLoading(true);
    setError("");
    getReviewQueue().then(setQueue).catch((e) => setError(e.message)).finally(() => setLoading(false));
  };

  useEffect(() => { fetchQueue(); }, []);

  const toggleHistory = async (caseId) => {
    if (openId === caseId) { setOpenId(null); return; }
    setOpenId(caseId);
    if (!history[caseId]) {
      try {
        const h = await getReviewHistory(caseId);
        setHistory((prev) => ({ ...prev, [caseId]: h }));
      } catch { /* ignore */ }
    }
  };

  return (
    <div>
      <div className="page-header">
        <div className="eyebrow">Forced escalation only</div>
        <h2>Human Review</h2>
        <p>Only cases routed to <code>manual</code> (re-run limit exceeded, or low confidence with elevated risk) land here. auto_clear and review-routed cases go straight to a report — they never need a human.</p>
      </div>

      <div className="panel">
        <div className="row" style={{ justifyContent: "space-between", marginBottom: 14 }}>
          <h3 style={{ margin: 0 }}>Manual review queue</h3>
          <button className="btn" onClick={fetchQueue}>Refresh</button>
        </div>

        <ErrorBox message={error} />
        <SuccessBox message={success} />

        {loading ? (
          <Loader label="Loading queue…" />
        ) : queue.length === 0 ? (
          <Empty>No cases are awaiting human review right now.</Empty>
        ) : (
          queue.map((c) => (
            <div key={c.id} style={{ padding: "12px 0", borderBottom: "1px solid var(--border)" }}>
              <div className="row" style={{ justifyContent: "space-between" }}>
                <div className="row">
                  <Link to={`/cases/${c.id}`} className="mono">{c.id}</Link>
                  <Badge value={c.routing} />
                  <span>{c.vendor}</span>
                  <span className="mono" style={{ color: "var(--muted)" }}>
                    {Number(c.amount_usd).toLocaleString(undefined, { maximumFractionDigits: 2 })}
                  </span>
                  <span className="mono" style={{ color: "var(--muted-2)", fontSize: 12 }}>posted by {c.posted_by}</span>
                </div>
                <div className="row">
                  <button className="btn" onClick={() => toggleHistory(c.id)}>
                    {openId === c.id ? "Close" : "Decide / history"}
                  </button>
                </div>
              </div>

              {openId === c.id && (
                <div>
                  {(history[c.id] || []).length > 0 && (
                    <div style={{ marginTop: 10 }}>
                      <div className="nav-label" style={{ padding: 0 }}>Past decisions</div>
                      {history[c.id].map((h) => (
                        <div key={h.id} className="row" style={{ fontSize: 12, color: "var(--muted)", margin: "4px 0" }}>
                          <Badge value={h.action} /> {h.actor} — {h.comment || "no comment"} ({(h.created_at || "").slice(0, 19)})
                        </div>
                      ))}
                    </div>
                  )}
                  <DecisionForm
                    caseRow={c}
                    onDone={() => { setSuccess(`Decision recorded for ${c.id}.`); setOpenId(null); fetchQueue(); }}
                  />
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
}
