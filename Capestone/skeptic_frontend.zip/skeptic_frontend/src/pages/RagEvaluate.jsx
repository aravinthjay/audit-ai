import { useEffect, useState } from "react";
import { ragEvaluateBatch, listRagEvaluations } from "../api";
import { ErrorBox, Loader, Empty } from "../components/Feedback";

const DEFAULT_QUESTIONS = [
  { query: "What GST rate applies to a hotel bill under INR 7500 per night?", expected_answer: "12 percent GST" },
  { query: "What is the pre-approval requirement for an expense above INR 25000?", expected_answer: "Senior Manager approval required" },
  { query: "What happens for duplicate expense submissions?", expected_answer: "termination, non-reimbursable" },
];

function ScoreBar({ value, max = 1, color = "var(--accent)" }) {
  const pct = Math.max(0, Math.min(100, (value / max) * 100));
  return (
    <div style={{ background: "var(--panel-2)", borderRadius: 3, height: 6, width: 90, overflow: "hidden" }}>
      <div style={{ background: color, height: "100%", width: `${pct}%` }} />
    </div>
  );
}

export default function RagEvaluate() {
  const [questions, setQuestions] = useState(DEFAULT_QUESTIONS);
  const [running, setRunning] = useState(false);
  const [error, setError] = useState("");
  const [batchResult, setBatchResult] = useState(null);

  const [history, setHistory] = useState([]);
  const [histLoading, setHistLoading] = useState(true);

  const fetchHistory = () => {
    setHistLoading(true);
    listRagEvaluations({ limit: 50 }).then(setHistory).catch(() => {}).finally(() => setHistLoading(false));
  };
  useEffect(() => { fetchHistory(); }, []);

  const updateQ = (i, field, value) => {
    setQuestions((qs) => qs.map((q, idx) => (idx === i ? { ...q, [field]: value } : q)));
  };
  const addQ = () => setQuestions((qs) => [...qs, { query: "", expected_answer: "" }]);
  const removeQ = (i) => setQuestions((qs) => qs.filter((_, idx) => idx !== i));

  const runEval = async () => {
    setRunning(true);
    setError("");
    setBatchResult(null);
    try {
      const valid = questions.filter((q) => q.query.trim());
      const res = await ragEvaluateBatch(valid);
      setBatchResult(res);
      fetchHistory();
    } catch (e) {
      setError(e.message);
    } finally {
      setRunning(false);
    }
  };

  return (
    <div>
      <div className="page-header">
        <div className="eyebrow">Standalone RAG eval harness</div>
        <h2>RAG Evaluation</h2>
        <p>
          Runs each question through retrieval + generation and scores retrieval relevance (cosine vs the TF-IDF
          index), groundedness (how much of the answer is lexically supported by retrieved chunks), and keyword
          match against an optional reference answer. Every run is persisted and also feeds Prometheus.
        </p>
      </div>

      <div className="panel">
        <h3>Question set</h3>
        {questions.map((q, i) => (
          <div key={i} className="row" style={{ marginBottom: 8 }}>
            <input
              placeholder="query"
              value={q.query}
              onChange={(e) => updateQ(i, "query", e.target.value)}
              style={{ flex: 2 }}
            />
            <input
              placeholder="expected_answer (optional)"
              value={q.expected_answer}
              onChange={(e) => updateQ(i, "expected_answer", e.target.value)}
              style={{ flex: 2 }}
            />
            <button className="btn btn-danger" type="button" onClick={() => removeQ(i)}>✕</button>
          </div>
        ))}
        <div className="row" style={{ marginTop: 10 }}>
          <button className="btn" type="button" onClick={addQ}>+ Add question</button>
          <button className="btn btn-primary" type="button" onClick={runEval} disabled={running} style={{ marginLeft: "auto" }}>
            {running ? <span className="spinner" /> : "Run evaluation"}
          </button>
        </div>
      </div>

      <ErrorBox message={error} />
      {running && <Loader label="Evaluating…" />}

      {batchResult && (
        <div className="panel">
          <h3>Aggregate — run {batchResult.aggregate.run_id}</h3>
          <div className="grid-3" style={{ marginBottom: 14 }}>
            <div className="metric-tile"><div className="label">Avg top relevance</div><div className="value">{batchResult.aggregate.avg_top_relevance_score}</div></div>
            <div className="metric-tile"><div className="label">Avg groundedness</div><div className="value">{batchResult.aggregate.avg_groundedness_score}</div></div>
            <div className="metric-tile"><div className="label">Avg latency (ms)</div><div className="value">{batchResult.aggregate.avg_latency_ms}</div></div>
          </div>
          <table>
            <thead><tr><th>Query</th><th>Top score</th><th>Groundedness</th><th>Keyword match</th><th>Answer</th></tr></thead>
            <tbody>
              {batchResult.results.map((r) => (
                <tr key={r.id}>
                  <td style={{ maxWidth: 220, fontSize: 12 }}>{r.query}</td>
                  <td><div className="row"><ScoreBar value={r.top_relevance_score} /><span className="mono" style={{ fontSize: 11 }}>{r.top_relevance_score}</span></div></td>
                  <td><div className="row"><ScoreBar value={r.groundedness_score} color="var(--good)" /><span className="mono" style={{ fontSize: 11 }}>{r.groundedness_score}</span></div></td>
                  <td className="mono" style={{ fontSize: 12 }}>{r.expected_answer ? r.keyword_match_score : "—"}</td>
                  <td style={{ maxWidth: 280, fontSize: 12, color: "var(--muted)" }}>{r.answer.slice(0, 160)}…</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <div className="panel">
        <div className="row" style={{ justifyContent: "space-between", marginBottom: 14 }}>
          <h3 style={{ margin: 0 }}>Past evaluations</h3>
          <button className="btn" onClick={fetchHistory}>Refresh</button>
        </div>
        {histLoading ? (
          <Loader label="Loading…" />
        ) : history.length === 0 ? (
          <Empty>No evaluations run yet.</Empty>
        ) : (
          <table>
            <thead><tr><th>Run</th><th>Query</th><th>Top score</th><th>Groundedness</th><th>Latency (ms)</th><th>When</th></tr></thead>
            <tbody>
              {history.map((r) => (
                <tr key={r.id}>
                  <td className="mono" style={{ fontSize: 11 }}>{r.run_id}</td>
                  <td style={{ maxWidth: 240, fontSize: 12 }}>{r.query}</td>
                  <td className="mono">{r.top_relevance_score}</td>
                  <td className="mono">{r.groundedness_score}</td>
                  <td className="mono">{r.latency_ms}</td>
                  <td className="mono" style={{ fontSize: 11, color: "var(--muted-2)" }}>{(r.created_at || "").slice(0, 19)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
