import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { getCase, runCase, getCaseAuditLog, verifyAuditChain } from "../api";
import { Loader, ErrorBox, Empty } from "../components/Feedback";
import Badge from "../components/Badge";

export default function CaseDetail() {
  const { caseId } = useParams();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [running, setRunning] = useState(false);

  const [log, setLog] = useState([]);
  const [verify, setVerify] = useState(null);
  const [tab, setTab] = useState("overview");

  const fetchAll = () => {
    setLoading(true);
    setError("");
    Promise.all([getCase(caseId), getCaseAuditLog(caseId).catch(() => [])])
      .then(([c, l]) => { setData(c); setLog(l); })
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  };

  useEffect(() => { fetchAll(); }, [caseId]); // eslint-disable-line

  const handleRun = async () => {
    setRunning(true);
    setError("");
    try {
      await runCase(caseId);
      fetchAll();
    } catch (e) {
      setError(e.message);
    } finally {
      setRunning(false);
    }
  };

  const handleVerify = async () => {
    try {
      setVerify(await verifyAuditChain(caseId));
    } catch (e) {
      setError(e.message);
    }
  };

  if (loading) return <Loader label="Loading case…" />;
  if (error && !data) return <ErrorBox message={error} />;
  if (!data) return <Empty>Case not found.</Empty>;

  return (
    <div>
      <div className="page-header">
        <div className="eyebrow"><Link to="/cases">← All cases</Link></div>
        <h2 className="mono">{data.id}</h2>
        <div className="row" style={{ marginTop: 8 }}>
          <Badge value={data.status} />
          <Badge value={data.routing} />
          {data.risk && <Badge value={data.risk} />}
          <button className="btn btn-primary" onClick={handleRun} disabled={running} style={{ marginLeft: "auto" }}>
            {running ? <span className="spinner" /> : (data.status === "report_ready" ? "Re-run pipeline" : "Run pipeline")}
          </button>
        </div>
      </div>

      <ErrorBox message={error} />

      <div className="grid-3" style={{ marginBottom: 4 }}>
        <div className="metric-tile"><div className="label">Vendor</div><div className="value" style={{ fontSize: 15 }}>{data.vendor}</div></div>
        <div className="metric-tile"><div className="label">Amount (USD)</div><div className="value">{Number(data.amount_usd).toLocaleString(undefined, { maximumFractionDigits: 2 })}</div></div>
        <div className="metric-tile"><div className="label">Confidence</div><div className="value">{data.confidence ?? "—"}</div></div>
      </div>

      <div className="tabs" style={{ marginTop: 20 }}>
        {["overview", "evidence", "debate", "adjudication", "audit chain"].map((t) => (
          <div key={t} className={"tab" + (tab === t ? " active" : "")} onClick={() => setTab(t)}>{t}</div>
        ))}
      </div>

      {tab === "overview" && (
        <div className="panel">
          <h3>Transaction</h3>
          <div className="kv"><span className="k">txn_id</span><span className="v">{data.txn_id}</span></div>
          <div className="kv"><span className="k">posted_by</span><span className="v">{data.posted_by}</span></div>
          <div className="kv"><span className="k">currency</span><span className="v">{data.currency}</span></div>
          <div className="kv"><span className="k">flags</span><span className="v">{(data.flags || []).join(", ") || "none"}</span></div>
          <div className="kv"><span className="k">attempt_count</span><span className="v">{data.attempt_count}</span></div>
          <div className="kv"><span className="k">disposition</span><span className="v">{data.disposition || "—"}</span></div>
          <div className="kv"><span className="k">escalation_reason</span><span className="v">{data.escalation_reason || "—"}</span></div>
        </div>
      )}

      {tab === "evidence" && (
        <div className="panel">
          <h3>Phase 1 — Evidence (RAG + FX)</h3>
          {data.evidence && data.evidence.policy_analysis ? (
            <>
              <div className="kv"><span className="k">policy confidence</span><span className="v">{data.evidence.policy_analysis.confidence}</span></div>
              <p style={{ fontSize: 13, lineHeight: 1.6 }}>{data.evidence.policy_analysis.answer}</p>
              <h3 style={{ marginTop: 18 }}>Citations</h3>
              {(data.evidence.policy_analysis.citations || []).map((c, i) => (
                <div key={i} className="mono" style={{ fontSize: 12, color: "var(--muted)", padding: "6px 0", borderBottom: "1px solid var(--border)" }}>{c}</div>
              ))}
              {data.evidence.fx_check && (
                <>
                  <h3 style={{ marginTop: 18 }}>FX check</h3>
                  <div className="kv"><span className="k">claimed_rate</span><span className="v">{data.evidence.fx_check.claimed_rate}</span></div>
                  <div className="kv"><span className="k">live_rate</span><span className="v">{data.evidence.fx_check.live_rate ?? "unavailable"}</span></div>
                  <div className="kv"><span className="k">outlier</span><span className="v">{String(data.evidence.fx_check.outlier)}</span></div>
                </>
              )}
            </>
          ) : <Empty>No evidence collected yet — run the pipeline.</Empty>}
        </div>
      )}

      {tab === "debate" && (
        <div className="panel">
          <h3>Phase 2 — Debate history ({(data.debate_history || []).length} attempt(s))</h3>
          {(data.debate_history || []).length === 0 ? <Empty>No debate rounds yet.</Empty> : (
            data.debate_history.map((round, i) => (
              <div key={i} style={{ marginBottom: 18, paddingBottom: 14, borderBottom: "1px solid var(--border)" }}>
                <div className="row" style={{ marginBottom: 8 }}>
                  <span className="badge">attempt {round.attempt}</span>
                  <Badge value={round.adjudication?.risk} />
                  <span className="mono" style={{ color: "var(--muted)" }}>confidence {round.adjudication?.confidence}</span>
                </div>
                <div className="grid-2">
                  <div>
                    <div className="nav-label" style={{ padding: 0, marginBottom: 6 }}>Challenger ({round.challenger?.confidence})</div>
                    <p style={{ fontSize: 13, color: "var(--text)" }}>{round.challenger?.argument}</p>
                  </div>
                  <div>
                    <div className="nav-label" style={{ padding: 0, marginBottom: 6 }}>Defender ({round.defender?.confidence})</div>
                    <p style={{ fontSize: 13, color: "var(--text)" }}>{round.defender?.argument}</p>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {tab === "adjudication" && (
        <div className="panel">
          <h3>Phase 3 — Final adjudication</h3>
          {data.adjudication && data.adjudication.summary ? (
            <>
              <div className="kv"><span className="k">risk</span><span className="v"><Badge value={data.adjudication.risk} /></span></div>
              <div className="kv"><span className="k">confidence</span><span className="v">{data.adjudication.confidence}</span></div>
              <div className="kv"><span className="k">disposition</span><span className="v">{data.adjudication.disposition}</span></div>
              <p style={{ fontSize: 13, marginTop: 12 }}>{data.adjudication.summary}</p>
            </>
          ) : <Empty>No adjudication yet — run the pipeline.</Empty>}
        </div>
      )}

      {tab === "audit chain" && (
        <div className="panel">
          <div className="row" style={{ justifyContent: "space-between", marginBottom: 14 }}>
            <h3 style={{ margin: 0 }}>Hash-chained audit log for this case</h3>
            <button className="btn" onClick={handleVerify}>Verify chain</button>
          </div>
          {verify && (
            verify.valid
              ? <div className="success-box">✓ Chain verified — {verify.checked} entries, unbroken.</div>
              : <div className="error-box">⚠ Chain broken at entry {verify.broken_at} (checked {verify.checked})</div>
          )}
          {log.length === 0 ? <Empty>No audit entries for this case yet.</Empty> : (
            <div>
              {log.map((entry) => (
                <div key={entry.id} style={{ padding: "10px 0", borderBottom: "1px solid var(--border)" }}>
                  <div className="row" style={{ justifyContent: "space-between" }}>
                    <span className="mono" style={{ fontSize: 12 }}>
                      <span className="flag-pill">{entry.event_type}</span> {entry.actor} — {entry.title}
                    </span>
                    <span className="mono" style={{ fontSize: 11, color: "var(--muted-2)" }}>{(entry.created_at || "").slice(0, 19)}</span>
                  </div>
                  <div className="hashchain" style={{ marginTop: 6 }}>
                    <span className="link">{entry.prev_hash?.slice(0, 10)}…</span>
                    <span className="arrow">→</span>
                    <span className="link" style={{ color: "var(--accent)" }}>{entry.hash?.slice(0, 10)}…</span>
                    {entry.langsmith_run_id && <span className="link" title="LangSmith run id">ls:{entry.langsmith_run_id.slice(0, 8)}…</span>}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
