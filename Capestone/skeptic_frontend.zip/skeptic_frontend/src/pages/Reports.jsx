import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { listReports } from "../api";
import { Loader, ErrorBox, Empty } from "../components/Feedback";
import Badge from "../components/Badge";

export default function Reports() {
  const [reports, setReports] = useState([]);
  const [routing, setRouting] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const fetch_ = () => {
    setLoading(true);
    setError("");
    listReports({ routing: routing || undefined, limit: 100 })
      .then(setReports)
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  };

  useEffect(() => { fetch_(); }, [routing]); // eslint-disable-line

  return (
    <div>
      <div className="page-header">
        <div className="eyebrow">Output</div>
        <h2>Reports</h2>
        <p>Final audit report per case — generated automatically for auto_clear and review routes, and after a human decision for manual cases.</p>
      </div>

      <div className="panel">
        <div className="row" style={{ justifyContent: "space-between", marginBottom: 14 }}>
          <select value={routing} onChange={(e) => setRouting(e.target.value)}>
            <option value="">All routings</option>
            <option value="auto_clear">auto_clear</option>
            <option value="review">review</option>
            <option value="manual">manual</option>
          </select>
          <button className="btn" onClick={fetch_}>Refresh</button>
        </div>

        <ErrorBox message={error} />

        {loading ? (
          <Loader label="Loading reports…" />
        ) : reports.length === 0 ? (
          <Empty>No reports generated yet — run a case in the Cases tab.</Empty>
        ) : (
          <table>
            <thead>
              <tr><th>Report ID</th><th>Case</th><th>Routing</th><th>Risk</th><th>Confidence</th><th>Human reviewed</th><th>Summary</th><th>Created</th></tr>
            </thead>
            <tbody>
              {reports.map((r) => (
                <tr key={r.id}>
                  <td className="mono">{r.id}</td>
                  <td className="mono"><Link to={`/cases/${r.case_id}`}>{r.case_id}</Link></td>
                  <td><Badge value={r.routing} /></td>
                  <td><Badge value={r.risk} /></td>
                  <td className="mono">{r.confidence}</td>
                  <td>{r.human_reviewed ? "yes" : "no"}</td>
                  <td style={{ maxWidth: 320, fontSize: 12 }}>{r.summary}</td>
                  <td className="mono" style={{ color: "var(--muted-2)", fontSize: 12 }}>{(r.created_at || "").slice(0, 19)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
