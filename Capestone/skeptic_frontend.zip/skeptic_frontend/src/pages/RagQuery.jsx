import { useState } from "react";
import { ragQuery } from "../api";
import { ErrorBox, Loader } from "../components/Feedback";

export default function RagQuery() {
  const [question, setQuestion] = useState("");
  const [caseId, setCaseId] = useState("");
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const submit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    setResult(null);
    try {
      setResult(await ragQuery(question, caseId || undefined));
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <div className="page-header">
        <div className="eyebrow">TF-IDF retrieval over company_policy.pdf</div>
        <h2>Policy Query</h2>
        <p>Ask the same RAG layer the debate agents use during Phase 1 evidence collection. Useful for testing retrieval quality directly. Token usage is logged under agent <code>rag-query</code>.</p>
      </div>

      <div className="panel">
        <form onSubmit={submit}>
          <textarea
            rows={3}
            style={{ width: "100%", marginBottom: 10 }}
            placeholder="e.g. What GST rate applies to a hotel bill under INR 7500 per night?"
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            required
          />
          <div className="row" style={{ justifyContent: "space-between" }}>
            <input
              placeholder="optional case_id to attribute tokens to"
              value={caseId}
              onChange={(e) => setCaseId(e.target.value)}
              className="mono"
              style={{ flex: 1, marginRight: 10 }}
            />
            <button className="btn btn-primary" type="submit" disabled={loading || !question.trim()}>
              {loading ? <span className="spinner" /> : "Ask policy"}
            </button>
          </div>
        </form>
      </div>

      <ErrorBox message={error} />
      {loading && <Loader label="Retrieving + generating…" />}

      {result && (
        <div className="panel">
          <h3>Answer</h3>
          <p style={{ fontSize: 14, lineHeight: 1.6 }}>{result.answer}</p>
          <h3 style={{ marginTop: 18 }}>Retrieved chunks ({result.retrieved_chunks.length})</h3>
          {result.retrieved_chunks.map((c, i) => (
            <div key={i} className="mono" style={{ fontSize: 12, color: "var(--muted)", padding: "8px 0", borderBottom: "1px solid var(--border)" }}>
              {c.slice(0, 400)}{c.length > 400 ? "…" : ""}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
