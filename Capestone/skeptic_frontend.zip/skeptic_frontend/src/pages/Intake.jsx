import { useEffect, useState } from "react";
import { uploadGlCsv, listTransactions } from "../api";
import { Loader, ErrorBox, SuccessBox, Empty } from "../components/Feedback";
import Badge from "../components/Badge";

export default function Intake() {
  const [file, setFile] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [uploadResult, setUploadResult] = useState(null);
  const [uploadError, setUploadError] = useState("");

  const [txns, setTxns] = useState([]);
  const [status, setStatus] = useState("");
  const [loading, setLoading] = useState(true);
  const [listError, setListError] = useState("");

  const fetchTxns = (statusFilter = status) => {
    setLoading(true);
    setListError("");
    listTransactions(statusFilter ? { status: statusFilter, limit: 100 } : { limit: 100 })
      .then(setTxns)
      .catch((e) => setListError(e.message))
      .finally(() => setLoading(false));
  };

  useEffect(() => { fetchTxns(); }, []); // eslint-disable-line

  const handleUpload = async (e) => {
    e.preventDefault();
    if (!file) return;
    setUploading(true);
    setUploadError("");
    setUploadResult(null);
    try {
      const result = await uploadGlCsv(file);
      setUploadResult(result);
      fetchTxns();
    } catch (e) {
      setUploadError(e.message);
    } finally {
      setUploading(false);
    }
  };

  return (
    <div>
      <div className="page-header">
        <div className="eyebrow">Phase 0</div>
        <h2>Intake</h2>
        <p>Upload a GL CSV/TSV export. Every row is parsed, cleaned, and run through 7 flagging rules — a case is created per flagged transaction.</p>
      </div>

      <div className="panel">
        <h3>Upload GL export</h3>
        <form onSubmit={handleUpload} className="row">
          <input
            type="file"
            accept=".csv,.tsv"
            onChange={(e) => setFile(e.target.files[0] || null)}
          />
          <button className="btn btn-primary" type="submit" disabled={!file || uploading}>
            {uploading ? <span className="spinner" /> : "Upload & flag"}
          </button>
        </form>
        <ErrorBox message={uploadError} />
        {uploadResult && (
          <SuccessBox
            message={`${uploadResult.file_name}: ${uploadResult.total_rows} rows parsed — ${uploadResult.flagged_count} flagged (cases created), ${uploadResult.cleared_count} cleared, ${uploadResult.parse_errors} parse errors.`}
          />
        )}
      </div>

      <div className="panel">
        <div className="row" style={{ justifyContent: "space-between", marginBottom: 14 }}>
          <h3 style={{ margin: 0 }}>Transactions</h3>
          <div className="row">
            <select value={status} onChange={(e) => { setStatus(e.target.value); fetchTxns(e.target.value); }}>
              <option value="">All statuses</option>
              <option value="flagged">Flagged</option>
              <option value="cleared">Cleared</option>
            </select>
            <button className="btn" onClick={() => fetchTxns()}>Refresh</button>
          </div>
        </div>

        {loading ? (
          <Loader label="Loading transactions…" />
        ) : listError ? (
          <ErrorBox message={listError} />
        ) : txns.length === 0 ? (
          <Empty>No transactions yet — upload a CSV above.</Empty>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Txn ID</th><th>Vendor</th><th>Amount (USD)</th><th>Posted by</th>
                <th>Status</th><th>Flags</th><th>Posted at</th>
              </tr>
            </thead>
            <tbody>
              {txns.map((t) => (
                <tr key={t.id}>
                  <td className="mono">{t.txn_id}</td>
                  <td>{t.vendor}</td>
                  <td className="mono">{Number(t.amount_usd).toLocaleString(undefined, { maximumFractionDigits: 2 })}</td>
                  <td className="mono">{t.posted_by}</td>
                  <td><Badge value={t.status} /></td>
                  <td>{(t.flags || []).map((f) => <span className="flag-pill" key={f}>{f}</span>)}</td>
                  <td className="mono" style={{ color: "var(--muted)" }}>{(t.posted_at || "").slice(0, 19)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
