import { useEffect, useState } from "react";
import { getFullAuditLog, verifyAuditChain } from "../api";
import { Loader, ErrorBox, Empty } from "../components/Feedback";

export default function AuditLog() {
  const [log, setLog] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [verifyCaseId, setVerifyCaseId] = useState("");
  const [verifyResult, setVerifyResult] = useState(null);
  const [verifyError, setVerifyError] = useState("");

  const fetchLog = () => {
    setLoading(true);
    setError("");
    getFullAuditLog(150).then(setLog).catch((e) => setError(e.message)).finally(() => setLoading(false));
  };

  useEffect(() => { fetchLog(); }, []);

  const runVerify = async (e) => {
    e.preventDefault();
    setVerifyError("");
    setVerifyResult(null);
    try {
      setVerifyResult(await verifyAuditChain(verifyCaseId.trim()));
    } catch (e) {
      setVerifyError(e.message);
    }
  };

  return (
    <div>
      <div className="page-header">
        <div className="eyebrow">Append-only · hash-chained</div>
        <h2>Audit Log</h2>
        <p>Every system, agent, and human event is appended here and chained by SHA-256 hash — never updated, never deleted. Each entry can also carry a LangSmith run id for jumping into the full LLM trace.</p>
      </div>

      <div className="panel">
        <h3>Verify a case's chain</h3>
        <form onSubmit={runVerify} className="row">
          <input
            placeholder="CASE-XXXXXXXX"
            value={verifyCaseId}
            onChange={(e) => setVerifyCaseId(e.target.value)}
            className="mono"
            style={{ flex: 1 }}
          />
          <button className="btn btn-primary" type="submit" disabled={!verifyCaseId.trim()}>Verify</button>
        </form>
        <ErrorBox message={verifyError} />
        {verifyResult && (
          verifyResult.valid
            ? <div className="success-box">✓ Chain verified — {verifyResult.checked} entries, unbroken.</div>
            : <div className="error-box">⚠ Chain broken at entry {verifyResult.broken_at} (checked {verifyResult.checked})</div>
        )}
      </div>

      <div className="panel">
        <div className="row" style={{ justifyContent: "space-between", marginBottom: 14 }}>
          <h3 style={{ margin: 0 }}>Full log (most recent first)</h3>
          <button className="btn" onClick={fetchLog}>Refresh</button>
        </div>
        <ErrorBox message={error} />
        {loading ? (
          <Loader label="Loading audit log…" />
        ) : log.length === 0 ? (
          <Empty>No events logged yet.</Empty>
        ) : (
          <table>
            <thead>
              <tr><th>Time</th><th>Type</th><th>Actor</th><th>Case</th><th>Title</th><th>Hash</th></tr>
            </thead>
            <tbody>
              {log.map((entry) => (
                <tr key={entry.id}>
                  <td className="mono" style={{ color: "var(--muted-2)", fontSize: 12 }}>{(entry.created_at || "").slice(0, 19)}</td>
                  <td><span className="flag-pill">{entry.event_type}</span></td>
                  <td className="mono">{entry.actor}</td>
                  <td className="mono">{entry.case_id || "—"}</td>
                  <td style={{ fontSize: 12 }}>{entry.title}</td>
                  <td className="mono" style={{ fontSize: 11, color: "var(--muted-2)" }}>{entry.hash?.slice(0, 12)}…</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
