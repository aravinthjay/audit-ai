import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { listCases, runCase } from "../api";
import { Loader, ErrorBox, Empty } from "../components/Feedback";
import Badge from "../components/Badge";

export default function Cases() {
  const [cases, setCases] = useState([]);
  const [status, setStatus] = useState("");
  const [routing, setRouting] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [runningId, setRunningId] = useState(null);

  const fetchCases = () => {
    setLoading(true);
    setError("");
    listCases({ status: status || undefined, routing: routing || undefined, limit: 100 })
      .then(setCases)
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  };

  useEffect(() => { fetchCases(); }, [status, routing]); // eslint-disable-line

  const handleRun = async (id) => {
    setRunningId(id);
    setError("");
    try {
      await runCase(id);
      fetchCases();
    } catch (e) {
      setError(`${id}: ${e.message}`);
    } finally {
      setRunningId(null);
    }
  };

  return (
    <div>
      <div className="page-header">
        <div className="eyebrow">Phase 1 → 2 → 3</div>
        <h2>Cases</h2>
        <p>Each flagged transaction is a case. Running a case executes evidence collection (RAG + FX), the adversarial debate, and the confidence gate that routes it to auto_clear, review, or manual.</p>
      </div>

      <div className="panel">
        <div className="row" style={{ justifyContent: "space-between", marginBottom: 14 }}>
          <div className="row">
            <select value={status} onChange={(e) => setStatus(e.target.value)}>
              <option value="">All statuses</option>
              <option value="intake">intake</option>
              <option value="collecting_evidence">collecting_evidence</option>
              <option value="agent_debate">agent_debate</option>
              <option value="pending_human_review">pending_human_review</option>
              <option value="report_ready">report_ready</option>
            </select>
            <select value={routing} onChange={(e) => setRouting(e.target.value)}>
              <option value="">All routings</option>
              <option value="auto_clear">auto_clear</option>
              <option value="review">review</option>
              <option value="manual">manual</option>
            </select>
          </div>
          <button className="btn" onClick={fetchCases}>Refresh</button>
        </div>

        <ErrorBox message={error} />

        {loading ? (
          <Loader label="Loading cases…" />
        ) : cases.length === 0 ? (
          <Empty>No cases match this filter. Upload a CSV in Intake to create some.</Empty>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Case ID</th><th>Vendor</th><th>Amount</th><th>Flags</th>
                <th>Status</th><th>Routing</th><th></th>
              </tr>
            </thead>
            <tbody>
              {cases.map((c) => (
                <tr key={c.id}>
                  <td className="mono"><Link to={`/cases/${c.id}`}>{c.id}</Link></td>
                  <td>{c.vendor}</td>
                  <td className="mono">{Number(c.amount_usd).toLocaleString(undefined, { maximumFractionDigits: 2 })}</td>
                  <td>{(c.flags || []).map((f) => <span className="flag-pill" key={f}>{f}</span>)}</td>
                  <td><Badge value={c.status} /></td>
                  <td><Badge value={c.routing} /></td>
                  <td>
                    <button
                      className="btn"
                      disabled={runningId === c.id}
                      onClick={() => handleRun(c.id)}
                      title="Run Phase 1–3 pipeline for this case"
                    >
                      {runningId === c.id ? <span className="spinner" /> : (c.status === "report_ready" ? "Re-run" : "Run")}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
