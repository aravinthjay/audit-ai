import { useEffect, useState } from "react";
import { getTokenUsage, getTokenUsageSummary } from "../api";
import { Loader, ErrorBox, Empty } from "../components/Feedback";

export default function Tokens() {
  const [summary, setSummary] = useState(null);
  const [rows, setRows] = useState([]);
  const [caseId, setCaseId] = useState("");
  const [agent, setAgent] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const fetchAll = () => {
    setLoading(true);
    setError("");
    Promise.all([
      getTokenUsageSummary(),
      getTokenUsage({ case_id: caseId || undefined, agent: agent || undefined, limit: 100 }),
    ])
      .then(([s, r]) => { setSummary(s); setRows(r); })
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  };

  useEffect(() => { fetchAll(); }, []); // eslint-disable-line

  const totals = summary?.totals || {};

  return (
    <div>
      <div className="page-header">
        <div className="eyebrow">Per-call, per-agent, per-case</div>
        <h2>Token Usage</h2>
        <p>Every Groq LLM call — challenger, defender, adjudicator, RAG query/eval — logs prompt/completion tokens, latency, and estimated cost here, mirrored to Prometheus.</p>
      </div>

      {loading ? <Loader label="Loading…" /> : (
        <>
          <div className="grid-3" style={{ marginBottom: 18 }}>
            <div className="metric-tile"><div className="label">Total tokens</div><div className="value">{(totals.total_tokens ?? 0).toLocaleString()}</div></div>
            <div className="metric-tile"><div className="label">Total calls</div><div className="value">{totals.call_count ?? 0}</div></div>
            <div className="metric-tile"><div className="label">Estimated cost (USD)</div><div className="value">${Number(totals.estimated_cost_usd ?? 0).toFixed(6)}</div></div>
          </div>

          <div className="panel">
            <h3>By agent / model</h3>
            {(summary?.by_agent_model || []).length === 0 ? <Empty>No usage logged yet.</Empty> : (
              <table>
                <thead><tr><th>Agent</th><th>Model</th><th>Prompt</th><th>Completion</th><th>Total</th><th>Calls</th><th>Avg latency (ms)</th><th>Cost (USD)</th></tr></thead>
                <tbody>
                  {summary.by_agent_model.map((r, i) => (
                    <tr key={i}>
                      <td><span className="flag-pill">{r.agent}</span></td>
                      <td className="mono" style={{ fontSize: 12 }}>{r.model}</td>
                      <td className="mono">{r.prompt_tokens}</td>
                      <td className="mono">{r.completion_tokens}</td>
                      <td className="mono">{r.total_tokens}</td>
                      <td className="mono">{r.call_count}</td>
                      <td className="mono">{Number(r.avg_latency_ms).toFixed(1)}</td>
                      <td className="mono">${Number(r.estimated_cost_usd).toFixed(6)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </>
      )}

      <div className="panel">
        <div className="row" style={{ justifyContent: "space-between", marginBottom: 14 }}>
          <h3 style={{ margin: 0 }}>Raw log</h3>
          <div className="row">
            <input placeholder="filter by case_id" value={caseId} onChange={(e) => setCaseId(e.target.value)} className="mono" />
            <select value={agent} onChange={(e) => setAgent(e.target.value)}>
              <option value="">All agents</option>
              <option value="challenger">challenger</option>
              <option value="defender">defender</option>
              <option value="adjudicator">adjudicator</option>
              <option value="rag-query">rag-query</option>
              <option value="rag-eval">rag-eval</option>
              <option value="evidence-rag">evidence-rag</option>
            </select>
            <button className="btn" onClick={fetchAll}>Apply</button>
          </div>
        </div>

        <ErrorBox message={error} />
        {rows.length === 0 ? <Empty>No matching usage rows.</Empty> : (
          <table>
            <thead><tr><th>Case</th><th>Agent</th><th>Prompt</th><th>Completion</th><th>Latency (ms)</th><th>Cost (USD)</th><th>When</th></tr></thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.id}>
                  <td className="mono" style={{ fontSize: 12 }}>{r.case_id || "—"}</td>
                  <td><span className="flag-pill">{r.agent}</span></td>
                  <td className="mono">{r.prompt_tokens}</td>
                  <td className="mono">{r.completion_tokens}</td>
                  <td className="mono">{Number(r.latency_ms).toFixed(0)}</td>
                  <td className="mono">${Number(r.estimated_cost_usd).toFixed(6)}</td>
                  <td className="mono" style={{ fontSize: 11, color: "var(--muted-2)" }}>{(r.created_at || "").slice(0, 19)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
