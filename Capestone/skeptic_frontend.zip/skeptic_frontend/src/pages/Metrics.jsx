import { useEffect, useState } from "react";
import { metricsUrl, docsUrl, API_HOST } from "../api";

export default function Metrics() {
  const [raw, setRaw] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch(metricsUrl)
      .then((r) => r.text())
      .then(setRaw)
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  const skepticLines = raw.split("\n").filter((l) => l.startsWith("skeptic_") && !l.startsWith("# "));

  return (
    <div>
      <div className="page-header">
        <div className="eyebrow">Prometheus + LangSmith</div>
        <h2>Metrics & Tracing</h2>
        <p>
          Prometheus scrapes <code>{metricsUrl}</code> directly — point a Prometheus/Grafana instance at it for dashboards and alerting.
          LangSmith traces every LLM/RAG call (challenger, defender, adjudicator, RAG retrieval + generation) when configured on the backend.
        </p>
      </div>

      <div className="grid-2">
        <div className="panel">
          <h3>Prometheus</h3>
          <p style={{ fontSize: 13 }}>Raw scrape endpoint:</p>
          <div className="row" style={{ marginBottom: 10 }}>
            <a href={metricsUrl} target="_blank" rel="noreferrer" className="mono">{metricsUrl}</a>
          </div>
          <p style={{ fontSize: 12, color: "var(--muted)" }}>
            Custom series exposed: <code>skeptic_llm_tokens_total</code>, <code>skeptic_llm_cost_usd_total</code>,{" "}
            <code>skeptic_llm_call_latency_seconds</code>, <code>skeptic_rag_top_relevance_score</code>,{" "}
            <code>skeptic_rag_groundedness_score</code>, <code>skeptic_case_routing_total</code>,{" "}
            <code>skeptic_debate_rounds_total</code>, plus standard HTTP request metrics.
          </p>
        </div>

        <div className="panel">
          <h3>LangSmith</h3>
          <p style={{ fontSize: 13 }}>
            Set <code>LANGSMITH_TRACING=true</code> and <code>LANGSMITH_API_KEY</code> in the backend's <code>.env</code>, then view traces at:
          </p>
          <a href="https://smith.langchain.com" target="_blank" rel="noreferrer">smith.langchain.com</a>
          <p style={{ fontSize: 12, color: "var(--muted)", marginTop: 10 }}>
            Project name defaults to <code>skeptic-engine</code> (<code>LANGSMITH_PROJECT</code> in .env). Each audit log entry and token usage row also stores the matching <code>langsmith_run_id</code> for cross-referencing.
          </p>
        </div>
      </div>

      <div className="panel">
        <h3>API docs (FastAPI / Swagger)</h3>
        <a href={docsUrl} target="_blank" rel="noreferrer" className="mono">{docsUrl}</a>
      </div>

      <div className="panel">
        <h3>Live skeptic_* series (snapshot)</h3>
        {loading && <p style={{ color: "var(--muted)", fontSize: 13 }}>Loading…</p>}
        {error && <div className="error-box">⚠ {error} — is the backend running at {API_HOST}?</div>}
        {!loading && !error && (
          skepticLines.length === 0 ? (
            <p style={{ fontSize: 13, color: "var(--muted)" }}>No custom metrics recorded yet — run a case or a RAG query first.</p>
          ) : (
            <pre className="mono" style={{ fontSize: 11, color: "var(--muted)", whiteSpace: "pre-wrap", maxHeight: 400, overflow: "auto" }}>
              {skepticLines.join("\n")}
            </pre>
          )
        )}
      </div>
    </div>
  );
}
