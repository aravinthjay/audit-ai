// src/api.js — one function per backend endpoint. Nothing else in the app
// talks to fetch() directly, so the whole integration surface lives here.

export const API_HOST = import.meta.env.VITE_API_HOST || "http://localhost:8000";
export const API_BASE = `${API_HOST}/api/v1`;

async function request(path, { method = "GET", body, isForm = false } = {}) {
  const opts = { method, headers: {} };
  if (body !== undefined) {
    if (isForm) {
      opts.body = body; // FormData — let the browser set the content-type
    } else {
      opts.headers["Content-Type"] = "application/json";
      opts.body = JSON.stringify(body);
    }
  }
  const res = await fetch(`${API_BASE}${path}`, opts);
  const text = await res.text();
  let data;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    data = text;
  }
  if (!res.ok) {
    const detail = (data && data.detail) || res.statusText || "Request failed";
    throw new Error(typeof detail === "string" ? detail : JSON.stringify(detail));
  }
  return data;
}

function qs(params = {}) {
  const clean = Object.entries(params).filter(([, v]) => v !== undefined && v !== null && v !== "");
  if (!clean.length) return "";
  return "?" + new URLSearchParams(clean).toString();
}

// ---- health ----
export async function getHealth() {
  const res = await fetch(`${API_HOST}/health`);
  if (!res.ok) throw new Error("backend unreachable");
  return res.json();
}

export const metricsUrl = `${API_HOST}/metrics`;
export const docsUrl = `${API_HOST}/docs`;

// ---- Phase 0 — Intake ----
export function uploadGlCsv(file) {
  const fd = new FormData();
  fd.append("file", file);
  return request("/intake/upload", { method: "POST", body: fd, isForm: true });
}
export function listTransactions(params = {}) {
  return request(`/intake/transactions${qs(params)}`);
}

// ---- Phase 1-3 — Cases / Pipeline ----
export function listCases(params = {}) {
  return request(`/cases${qs(params)}`);
}
export function getCase(caseId) {
  return request(`/cases/${caseId}`);
}
export function runCase(caseId) {
  return request(`/cases/${caseId}/run`, { method: "POST" });
}

// ---- Phase 3 — Human review (manual queue only) ----
export function getReviewQueue() {
  return request("/review/queue");
}
export function decideReview(caseId, payload) {
  return request(`/review/${caseId}/decide`, { method: "POST", body: payload });
}
export function getReviewHistory(caseId) {
  return request(`/review/${caseId}/history`);
}

// ---- Reports ----
export function listReports(params = {}) {
  return request(`/reports${qs(params)}`);
}
export function getReport(caseId) {
  return request(`/reports/${caseId}`);
}

// ---- Audit log (hash chain) ----
export function getFullAuditLog(limit = 100) {
  return request(`/audit${qs({ limit })}`);
}
export function getCaseAuditLog(caseId) {
  return request(`/audit/${caseId}`);
}
export function verifyAuditChain(caseId) {
  return request(`/audit/${caseId}/verify`);
}

// ---- RAG: query + evaluation ----
export function ragQuery(question, caseId) {
  return request("/rag/query", { method: "POST", body: { question, case_id: caseId || null } });
}
export function ragEvaluateBatch(questions) {
  return request("/rag/evaluate", { method: "POST", body: { questions } });
}
export function ragEvaluateSingle(query, expected_answer = "") {
  return request("/rag/evaluate/single", { method: "POST", body: { query, expected_answer } });
}
export function listRagEvaluations(params = {}) {
  return request(`/rag/evaluations${qs(params)}`);
}

// ---- Token usage ----
export function getTokenUsage(params = {}) {
  return request(`/tokens/usage${qs(params)}`);
}
export function getTokenUsageSummary() {
  return request("/tokens/usage/summary");
}
